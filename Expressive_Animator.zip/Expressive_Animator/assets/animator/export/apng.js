let e,
  t,
  n,
  s,
  r,
  i = !1,
  a = !1;
function o(e, t) {
  self.postMessage([2, [e, t]]);
}
class u {
  #e = null;
  #t;
  #n;
  constructor(e, t) {
    ((this.#n = e), (this.#t = t));
  }
  async fetch(e) {
    const n = await (function (e) {
      return new Promise((n) => {
        ((t = n), self.postMessage([1, e]));
      });
    })(e);
    return void 0 === n
      ? this.#e
      : (this.#s(), this.#n ? (this.#e = await this.#n(n)) : (this.#e = n));
  }
  #s() {
    null != this.#e && (this.#t?.(this.#e), (this.#e = null));
  }
  dispose() {
    (this.#s(), (this.#n = this.#t = null));
  }
}
function f(e) {
  const t = new DataView(new ArrayBuffer(4));
  return (t.setUint32(0, e), t.buffer);
}
function c(e, t, n) {
  const s = new DataView(new ArrayBuffer(38));
  return (
    s.setUint32(0, 26),
    s.setUint32(4, 1717785676),
    s.setUint32(8, t),
    s.setUint32(12, e.width),
    s.setUint32(16, e.height),
    s.setUint32(20, 0),
    s.setUint32(24, 0),
    s.setUint16(28, 1),
    s.setUint16(30, n),
    s.setUint16(32, 0),
    s.setUint16(33, 0),
    s.setUint32(34, h(s.buffer.slice(4, 34))),
    s.buffer
  );
}
function* l(e) {
  const t = new DataView(e);
  let n = 8;
  do {
    const s = t.getUint32(n);
    (1229209940 === t.getUint32(n + 4) && (yield e.slice(n + 8, n + 8 + s)),
      (n += 12 + s));
  } while (n < t.byteLength);
}
function h(...e) {
  r ??= (function () {
    const e = new Uint32Array(256);
    for (let t = 0; t < 256; t++) {
      let n = t;
      for (let s = 0; s < 8; s++)
        (1 & n ? (n = (3988292384 ^ (n >>> 1)) >>> 0) : (n >>>= 1), (e[t] = n));
    }
    return e;
  })();
  let t = 4294967295;
  for (const n of e) {
    const e = new Uint8Array(n);
    for (let n = 0; n < e.byteLength; n++) t = r[255 & (t ^ e[n])] ^ (t >>> 8);
  }
  return (4294967295 ^ t) >>> 0;
}
var w;
((w = async function (e, t) {
  const s = (function (e, t, n) {
    const s = new OffscreenCanvas(e, t),
      r = s.getContext("bitmaprenderer");
    return new u(
      async (e) => (
        r.transferFromImageBitmap(e),
        e.close(),
        (await s.convertToBlob(n)).arrayBuffer()
      ),
    );
  })(e.size.width, e.size.height, { type: "image/png" });
  try {
    await (function (e, t) {
      let n = 0;
      const s = e.repeat || 0,
        r = (function* (e) {
          const t = e.startTime || 0,
            n = e.speed || 1,
            s = e.fps * (n < 1 ? 1 / n : 1),
            r = 1e3 / s,
            o = Math.ceil(e.duration / r);
          let u = 0,
            f = !e.reverse;
          const c = 1 * o,
            l = e.keyframe || 0,
            h = {
              time: 0,
              frame: 0,
              relativeFrame: 0,
              timestamp: 0,
              keyframe: !1,
              progress: 0,
              fps: s,
              totalRepeats: 1,
              totalFrames: c,
            };
          for (let s = 0; s < 1; s++) {
            for (let e = u; e < o; e++) {
              if (i || a) return h;
              ((h.relativeFrame = f ? e : o - 1 - e),
                (h.time = t + Math.round(h.relativeFrame * r)),
                (h.frame = s * o + e),
                (h.timestamp = 1e3 * Math.round((h.frame * r) / n)),
                (h.keyframe = l ? !(h.frame % l) : e === u || !(h.frame % 120)),
                (h.progress = h.frame / c),
                yield h);
            }
            e.alternate && ((f = !f), (u = 1));
          }
          return h;
        })(e);
      return new ReadableStream({
        async start(i) {
          const { value: a, done: u } = r.next();
          if (u) return void i.close();
          o(a.progress);
          const w = await t.fetch(a.time);
          for (const e of (function* (e) {
            const t = new DataView(e);
            yield t.buffer.slice(0, 8);
            let n = 8;
            do {
              const e = t.getUint32(n),
                s = t.getUint32(n + 4);
              ((1229472850 !== s && 1347179589 !== s) ||
                (yield t.buffer.slice(n, n + 12 + e)),
                (n += 12 + e));
            } while (n < e.byteLength);
          })(w))
            i.enqueue(e);
          (i.enqueue(
            (function (e, t) {
              const n = new DataView(new ArrayBuffer(20));
              return (
                n.setUint32(0, 8),
                n.setUint32(4, 1633899596),
                n.setUint32(8, t),
                n.setUint32(12, e),
                n.setUint32(16, h(n.buffer.slice(4, 16))),
                n.buffer
              );
            })(s, a.totalFrames),
          ),
            i.enqueue(c(e.size, n, a.fps)));
          for (const e of l(w)) {
            const t = f(1229209940);
            (i.enqueue(f(e.byteLength)),
              i.enqueue(t),
              i.enqueue(e),
              i.enqueue(f(h(t, e))));
          }
        },
        async pull(s) {
          n++;
          const { value: i, done: a } = r.next();
          if (a)
            return (
              o(1),
              s.enqueue(
                (function () {
                  const e = new DataView(new ArrayBuffer(12));
                  return (
                    e.setUint32(0, 0),
                    e.setUint32(4, 1229278788),
                    e.setUint32(8, h(e.buffer.slice(4, 8))),
                    e.buffer
                  );
                })(),
              ),
              void s.close()
            );
          o(i.progress);
          const u = await t.fetch(i.time);
          s.enqueue(new Uint8Array(c(e.size, n, i.fps)));
          for (const e of l(u)) {
            const t = f(++n),
              r = f(1717846356);
            (s.enqueue(f(e.byteLength + 4)),
              s.enqueue(r),
              s.enqueue(t),
              s.enqueue(e),
              s.enqueue(f(h(r, t, e))));
          }
        },
      });
    })(e, s).pipeTo(await t.createWritable(), {
      signal: (n ??= new AbortController()).signal,
    });
  } finally {
    s.dispose();
  }
}),
  e ||
    ((i = a = !1),
    (s = null),
    (n = null),
    (self.onmessage = async function (r) {
      const [o, u] = r.data;
      switch (o) {
        case 0:
          if (e)
            try {
              await e(u[0], u[1]);
            } catch (r) {
              i || ((f = r), (a = !0), (f ??= "Unknown error"), (s = f + ""));
            } finally {
              ((e = null),
                (function () {
                  const e = { type: i ? "aborted" : a ? "error" : "ok" };
                  ("error" === e.type && (e.message = s),
                    self.postMessage([3, e]));
                })());
            }
          return;
        case 1:
          return (t?.(u), void (t = null));
        case 2:
          return void (i || ((i = !0), n?.abort("Client aborted")));
      }
      var f;
    }),
    (e = w),
    self.postMessage([0])));
