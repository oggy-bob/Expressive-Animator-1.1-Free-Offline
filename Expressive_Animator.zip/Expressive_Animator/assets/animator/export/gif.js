let t,
  e,
  r,
  n,
  a = !1,
  i = !1;
function o(t, e) {
  self.postMessage([2, [t, e]]);
}
function c(t = 256) {
  let e = 0,
    r = new Uint8Array(t);
  return {
    get buffer() {
      return r.buffer;
    },
    reset() {
      e = 0;
    },
    bytesView: () => r.subarray(0, e),
    bytes: () => r.slice(0, e),
    writeByte(t) {
      (n(e + 1), (r[e] = t), e++);
    },
    writeBytes(t, a = 0, i = t.length) {
      n(e + i);
      for (let n = 0; n < i; n++) r[e++] = t[n + a];
    },
    writeBytesView(t, a = 0, i = t.byteLength) {
      (n(e + i), r.set(t.subarray(a, a + i), e), (e += i));
    },
  };
  function n(t) {
    let n = r.length;
    if (n >= t) return;
    ((t = Math.max(t, (n * (n < 1048576 ? 2 : 1.125)) >>> 0)),
      0 != n && (t = Math.max(t, 256)));
    const a = r;
    ((r = new Uint8Array(t)), e > 0 && r.set(a.subarray(0, e), 0));
  }
}
const s = [
  0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767,
  65535,
];
function l(t, e, r) {
  return ((t << 8) & 63488) | ((e << 2) & 992) | (r >> 3);
}
function f(t, e, r, n) {
  return (t >> 4) | (240 & e) | ((240 & r) << 4) | ((240 & n) << 8);
}
function u(t, e, r) {
  return ((t >> 4) << 8) | (240 & e) | (r >> 4);
}
function w(t, e, r) {
  return t < e ? e : t > r ? r : t;
}
function y(t) {
  return t * t;
}
function h(t, e, r) {
  let n = 0,
    a = 1e100;
  const i = t[e],
    o = i.cnt,
    c = i.ac,
    s = i.rc,
    l = i.gc,
    f = i.bc;
  for (let e = i.fw; 0 != e; e = t[e].fw) {
    const i = t[e],
      u = i.cnt,
      w = (o * u) / (o + u);
    if (w >= a) continue;
    let h = 0;
    (r && ((h += w * y(i.ac - c)), h >= a)) ||
      ((h += w * y(i.rc - s)),
      h >= a ||
        ((h += w * y(i.gc - l)),
        h >= a || ((h += w * y(i.bc - f)), h >= a || ((a = h), (n = e)))));
  }
  ((i.err = a), (i.nn = n));
}
function m(t, e, r = {}) {
  const {
    format: n = "rgb565",
    clearAlpha: a = !0,
    clearAlphaColor: i = 0,
    clearAlphaThreshold: o = 0,
    oneBitAlpha: c = !1,
  } = r;
  if (!t || !t.buffer)
    throw new Error("quantize() expected RGBA Uint8Array data");
  if (!(t instanceof Uint8Array || t instanceof Uint8ClampedArray))
    throw new Error("quantize() expected RGBA Uint8Array data");
  const s = new Uint32Array(t.buffer);
  let m = !1 !== r.useSqrt;
  const g = "rgba4444" === n,
    p = (function (t, e) {
      const r = new Array("rgb444" === e ? 4096 : 65536),
        n = t.length;
      if ("rgba4444" === e)
        for (let e = 0; e < n; ++e) {
          const n = t[e],
            a = (n >> 24) & 255,
            i = (n >> 16) & 255,
            o = (n >> 8) & 255,
            c = 255 & n,
            s = f(c, o, i, a);
          let l =
            s in r
              ? r[s]
              : (r[s] = {
                  ac: 0,
                  rc: 0,
                  gc: 0,
                  bc: 0,
                  cnt: 0,
                  nn: 0,
                  fw: 0,
                  bk: 0,
                  tm: 0,
                  mtm: 0,
                  err: 0,
                });
          ((l.rc += c), (l.gc += o), (l.bc += i), (l.ac += a), l.cnt++);
        }
      else if ("rgb444" === e)
        for (let e = 0; e < n; ++e) {
          const n = t[e],
            a = (n >> 16) & 255,
            i = (n >> 8) & 255,
            o = 255 & n,
            c = u(o, i, a);
          let s =
            c in r
              ? r[c]
              : (r[c] = {
                  ac: 0,
                  rc: 0,
                  gc: 0,
                  bc: 0,
                  cnt: 0,
                  nn: 0,
                  fw: 0,
                  bk: 0,
                  tm: 0,
                  mtm: 0,
                  err: 0,
                });
          ((s.rc += o), (s.gc += i), (s.bc += a), s.cnt++);
        }
      else
        for (let e = 0; e < n; ++e) {
          const n = t[e],
            a = (n >> 16) & 255,
            i = (n >> 8) & 255,
            o = 255 & n,
            c = l(o, i, a);
          let s =
            c in r
              ? r[c]
              : (r[c] = {
                  ac: 0,
                  rc: 0,
                  gc: 0,
                  bc: 0,
                  cnt: 0,
                  nn: 0,
                  fw: 0,
                  bk: 0,
                  tm: 0,
                  mtm: 0,
                  err: 0,
                });
          ((s.rc += o), (s.gc += i), (s.bc += a), s.cnt++);
        }
      return r;
    })(s, n),
    d = p.length,
    B = d - 1,
    A = new Uint32Array(d + 1);
  var M = 0;
  for (let t = 0; t < d; ++t) {
    const e = p[t];
    if (null != e) {
      let t = 1 / e.cnt;
      (g && (e.ac *= t), (e.rc *= t), (e.gc *= t), (e.bc *= t), (p[M++] = e));
    }
  }
  y(e) / M < 0.022 && (m = !1);
  let U,
    k,
    v,
    x = 0;
  for (; x < M - 1; ++x)
    ((p[x].fw = x + 1),
      (p[x + 1].bk = x),
      m && (p[x].cnt = Math.sqrt(p[x].cnt)));
  for (m && (p[x].cnt = Math.sqrt(p[x].cnt)), x = 0; x < M; ++x) {
    h(p, x, !1);
    let t = p[x].err;
    for (k = ++A[0]; k > 1 && ((v = k >> 1), !(p[(U = A[v])].err <= t)); k = v)
      A[k] = U;
    A[k] = x;
  }
  let C = M - e;
  for (x = 0; x < C; ) {
    let t;
    for (;;) {
      let e = A[1];
      if (((t = p[e]), t.tm >= t.mtm && p[t.nn].mtm <= t.tm)) break;
      t.mtm == B ? (e = A[1] = A[A[0]--]) : (h(p, e, !1), (t.tm = x));
      let r = p[e].err;
      for (
        k = 1;
        (v = k + k) <= A[0] &&
        (v < A[0] && p[A[v]].err > p[A[v + 1]].err && v++,
        !(r <= p[(U = A[v])].err));
        k = v
      )
        A[k] = U;
      A[k] = e;
    }
    let e = p[t.nn],
      r = t.cnt,
      n = e.cnt,
      a = 1 / (r + n);
    (g && (t.ac = a * (r * t.ac + n * e.ac)),
      (t.rc = a * (r * t.rc + n * e.rc)),
      (t.gc = a * (r * t.gc + n * e.gc)),
      (t.bc = a * (r * t.bc + n * e.bc)),
      (t.cnt += e.cnt),
      (t.mtm = ++x),
      (p[e.bk].fw = e.fw),
      (p[e.fw].bk = e.bk),
      (e.mtm = B));
  }
  let F = [],
    V = 0;
  for (x = 0; ; ++V) {
    let t = w(Math.round(p[x].rc), 0, 255),
      e = w(Math.round(p[x].gc), 0, 255),
      r = w(Math.round(p[x].bc), 0, 255),
      n = 255;
    g &&
      ((n = w(Math.round(p[x].ac), 0, 255)),
      c && (n = n <= ("number" == typeof c ? c : 127) ? 0 : 255),
      a && n <= o && ((t = e = r = i), (n = 0)));
    const s = g ? [t, e, r, n] : [t, e, r];
    if ((b(F, s) || F.push(s), 0 == (x = p[x].fw))) break;
  }
  return F;
}
function b(t, e) {
  for (let r = 0; r < t.length; r++) {
    const n = t[r];
    let a = n[0] === e[0] && n[1] === e[1] && n[2] === e[2],
      i = !(n.length >= 4 && e.length >= 4) || n[3] === e[3];
    if (a && i) return !0;
  }
  return !1;
}
function g(t, e) {
  let r,
    n = 0;
  for (r = 0; r < t.length; r++) {
    const a = t[r] - e[r];
    n += a * a;
  }
  return n;
}
function p(t, e, r = "rgb565") {
  if (!t || !t.buffer)
    throw new Error("quantize() expected RGBA Uint8Array data");
  if (!(t instanceof Uint8Array || t instanceof Uint8ClampedArray))
    throw new Error("quantize() expected RGBA Uint8Array data");
  if (e.length > 256)
    throw new Error("applyPalette() only works with 256 colors or less");
  const n = new Uint32Array(t.buffer),
    a = n.length,
    i = "rgb444" === r ? 4096 : 65536,
    o = new Uint8Array(a),
    c = new Array(i);
  if ("rgba4444" === r)
    for (let t = 0; t < a; t++) {
      const r = n[t],
        a = (r >> 24) & 255,
        i = (r >> 16) & 255,
        s = (r >> 8) & 255,
        l = 255 & r,
        u = f(l, s, i, a),
        w = u in c ? c[u] : (c[u] = d(l, s, i, a, e));
      o[t] = w;
    }
  else {
    const t = "rgb444" === r ? u : l;
    for (let r = 0; r < a; r++) {
      const a = n[r],
        i = (a >> 16) & 255,
        s = (a >> 8) & 255,
        l = 255 & a,
        f = t(l, s, i),
        u = f in c ? c[f] : (c[f] = B(l, s, i, e));
      o[r] = u;
    }
  }
  return o;
}
function d(t, e, r, n, a) {
  let i = 0,
    o = 1e100;
  for (let c = 0; c < a.length; c++) {
    const s = a[c];
    let l = A(s[3] - n);
    l > o ||
      ((l += A(s[0] - t)),
      l > o ||
        ((l += A(s[1] - e)),
        l > o || ((l += A(s[2] - r)), l > o || ((o = l), (i = c)))));
  }
  return i;
}
function B(t, e, r, n) {
  let a = 0,
    i = 1e100;
  for (let o = 0; o < n.length; o++) {
    const c = n[o];
    let s = A(c[0] - t);
    s > i ||
      ((s += A(c[1] - e)),
      s > i || ((s += A(c[2] - r)), s > i || ((i = s), (a = o))));
  }
  return a;
}
function A(t) {
  return t * t;
}
function M(t, e, r = g) {
  let n = 1 / 0,
    a = -1;
  for (let i = 0; i < t.length; i++) {
    const o = r(e, t[i]);
    o < n && ((n = o), (a = i));
  }
  return a;
}
function U(t, e) {
  const r = 1 << x(e.length);
  for (let n = 0; n < r; n++) {
    let r = [0, 0, 0];
    (n < e.length && (r = e[n]),
      t.writeByte(r[0]),
      t.writeByte(r[1]),
      t.writeByte(r[2]));
  }
}
function k(t, e) {
  (t.writeByte(255 & e), t.writeByte((e >> 8) & 255));
}
function v(t, e) {
  for (let r = 0; r < e.length; r++) t.writeByte(e.charCodeAt(r));
}
function x(t) {
  return Math.max(Math.ceil(Math.log2(t)), 1);
}
class C {
  #t = null;
  #e;
  #r;
  constructor(t, e) {
    ((this.#r = t), (this.#e = e));
  }
  async fetch(t) {
    const r = await (function (t) {
      return new Promise((r) => {
        ((e = r), self.postMessage([1, t]));
      });
    })(t);
    return void 0 === r
      ? this.#t
      : (this.#n(), this.#r ? (this.#t = await this.#r(r)) : (this.#t = r));
  }
  #n() {
    null != this.#t && (this.#e?.(this.#t), (this.#t = null));
  }
  dispose() {
    (this.#n(), (this.#r = this.#e = null));
  }
}
var F;
((F = async function (t, e) {
  const r = await e.createWritable(),
    n =
      ((l ??= { timestamp: 0 }),
      new C(async (t) => {
        const e = new VideoFrame(t, l),
          r = new ArrayBuffer(e.allocationSize());
        return (await e.copyTo(r), e.close(), t.close(), new Uint8Array(r));
      }));
  var l;
  try {
    await (async function (t, e, r) {
      const n = (function (t = {}) {
          const { initialCapacity: e = 4096, auto: r = !0 } = t,
            n = c(e),
            a = new Uint8Array(256),
            i = new Int32Array(5003),
            o = new Int32Array(5003);
          let l = !1;
          return {
            reset() {
              n.reset();
            },
            finish() {
              n.writeByte(59);
            },
            bytes: () => n.bytes(),
            bytesView: () => n.bytesView(),
            get buffer() {
              return n.buffer;
            },
            get stream() {
              return n;
            },
            writeHeader: f,
            writeFrame(t, e, u, w = {}) {
              const {
                transparent: y = !1,
                transparentIndex: h = 0,
                delay: m = 0,
                palette: b = null,
                repeat: g = 0,
                colorDepth: p = 8,
                dispose: d = -1,
              } = w;
              let B = !1;
              if (
                (r ? l || ((B = !0), f(), (l = !0)) : (B = Boolean(w.first)),
                (e = Math.max(0, Math.floor(e))),
                (u = Math.max(0, Math.floor(u))),
                B)
              ) {
                if (!b)
                  throw new Error(
                    "First frame must include a { palette } option",
                  );
                (!(function (t, e, r, n, a = 8) {
                  const i = 128 | ((a - 1) << 4) | (x(n.length) - 1);
                  (k(t, e), k(t, r), t.writeBytes([i, 0, 0]));
                })(n, e, u, b, p),
                  U(n, b),
                  g >= 0 &&
                    (function (t, e) {
                      (t.writeByte(33),
                        t.writeByte(255),
                        t.writeByte(11),
                        v(t, "NETSCAPE2.0"),
                        t.writeByte(3),
                        t.writeByte(1),
                        k(t, e),
                        t.writeByte(0));
                    })(n, g));
              }
              const A = Math.round(m / 10);
              !(function (t, e, r, n, a) {
                let i, o;
                (t.writeByte(33),
                  t.writeByte(249),
                  t.writeByte(4),
                  a < 0 && ((a = 0), (n = !1)),
                  n ? ((i = 1), (o = 2)) : ((i = 0), (o = 0)),
                  e >= 0 && (o = 7 & e),
                  (o <<= 2),
                  t.writeByte(o | i),
                  k(t, r),
                  t.writeByte(a || 0),
                  t.writeByte(0));
              })(n, d, A, y, h);
              const M = Boolean(b) && !B;
              (!(function (t, e, r, n) {
                if ((t.writeByte(44), k(t, 0), k(t, 0), k(t, e), k(t, r), n)) {
                  const e = 0,
                    r = 0,
                    a = x(n.length) - 1;
                  t.writeByte(128 | e | r | a);
                } else t.writeByte(0);
              })(n, e, u, M ? b : null),
                M && U(n, b),
                (function (t, e, r, n, a = 8, i, o, l) {
                  !(function (
                    t,
                    e,
                    r,
                    n,
                    a = c(512),
                    i = new Uint8Array(256),
                    o = new Int32Array(5003),
                    l = new Int32Array(5003),
                  ) {
                    const f = o.length,
                      u = Math.max(2, n);
                    (i.fill(0), l.fill(0), o.fill(-1));
                    let w = 0,
                      y = 0;
                    const h = u + 1,
                      m = h;
                    let b = !1,
                      g = m,
                      p = (1 << g) - 1;
                    const d = 1 << (h - 1),
                      B = d + 1;
                    let A = d + 2,
                      M = 0,
                      U = r[0],
                      k = 0;
                    for (let t = f; t < 65536; t *= 2) ++k;
                    ((k = 8 - k), a.writeByte(u), x(d));
                    const v = r.length;
                    for (let t = 1; t < v; t++)
                      t: {
                        const e = r[t],
                          n = (e << 12) + U;
                        let a = (e << k) ^ U;
                        if (o[a] === n) {
                          U = l[a];
                          break t;
                        }
                        const i = 0 === a ? 1 : f - a;
                        for (; o[a] >= 0; )
                          if (((a -= i), a < 0 && (a += f), o[a] === n)) {
                            U = l[a];
                            break t;
                          }
                        (x(U),
                          (U = e),
                          A < 4096
                            ? ((l[a] = A++), (o[a] = n))
                            : (o.fill(-1), (A = d + 2), (b = !0), x(d)));
                      }
                    return (x(U), x(B), a.writeByte(0), a.bytesView());
                    function x(t) {
                      for (
                        w &= s[y], y > 0 ? (w |= t << y) : (w = t), y += g;
                        y >= 8;
                      )
                        ((i[M++] = 255 & w),
                          M >= 254 &&
                            (a.writeByte(M),
                            a.writeBytesView(i, 0, M),
                            (M = 0)),
                          (w >>= 8),
                          (y -= 8));
                      if (
                        ((A > p || b) &&
                          (b
                            ? ((g = m), (p = (1 << g) - 1), (b = !1))
                            : (++g, (p = 12 === g ? 1 << g : (1 << g) - 1))),
                        t == B)
                      ) {
                        for (; y > 0; )
                          ((i[M++] = 255 & w),
                            M >= 254 &&
                              (a.writeByte(M),
                              a.writeBytesView(i, 0, M),
                              (M = 0)),
                            (w >>= 8),
                            (y -= 8));
                        M > 0 &&
                          (a.writeByte(M), a.writeBytesView(i, 0, M), (M = 0));
                      }
                    }
                  })(0, 0, e, a, t, i, o, l);
                })(n, t, 0, 0, p, a, i, o));
            },
          };
          function f() {
            v(n, "GIF89a");
          }
        })(),
        l = t.transparent ?? null,
        f = null != l;
      let u = t.repeat || 0;
      1 === u ? (u = -1) : 0 !== u && u--;
      let w = null;
      for (const c of (function* (t) {
        const e = t.startTime || 0,
          r = t.speed || 1,
          n = t.fps * (r < 1 ? 1 / r : 1),
          o = 1e3 / n,
          c = Math.ceil(t.duration / o);
        let s = 0,
          l = !t.reverse;
        const f = 1 * c,
          u = t.keyframe || 0,
          w = {
            time: 0,
            frame: 0,
            relativeFrame: 0,
            timestamp: 0,
            keyframe: !1,
            progress: 0,
            fps: n,
            totalRepeats: 1,
            totalFrames: f,
          };
        for (let n = 0; n < 1; n++) {
          for (let t = s; t < c; t++) {
            if (a || i) return w;
            ((w.relativeFrame = l ? t : c - 1 - t),
              (w.time = e + Math.round(w.relativeFrame * o)),
              (w.frame = n * c + t),
              (w.timestamp = 1e3 * Math.round((w.frame * o) / r)),
              (w.keyframe = u ? !(w.frame % u) : t === s || !(w.frame % 120)),
              (w.progress = w.frame / f),
              yield w);
          }
          t.alternate && ((l = !l), (s = 1));
        }
        return w;
      })(t)) {
        o(c.progress);
        const a = await e.fetch(c.time),
          i = m(a, 256),
          s = f ? M(i, l) : -1;
        (n.writeFrame(p(a, i), t.size.width, t.size.height, {
          palette: i,
          delay: c.frame > 0 ? (w ??= Math.round(1e3 / c.fps)) : 0,
          transparent: f,
          transparentIndex: s,
          repeat: u,
        }),
          c.frame % c.fps < 1 && (await r.write(n.bytes()), n.reset()));
      }
      a || i || (o(1), await n.finish(), await r.write(n.bytes()));
    })(t, n, r);
  } finally {
    (n.dispose(), await r.close());
  }
}),
  t ||
    ((a = i = !1),
    (n = null),
    (r = null),
    (self.onmessage = async function (r) {
      const [o, c] = r.data;
      switch (o) {
        case 0:
          if (t)
            try {
              await t(c[0], c[1]);
            } catch (r) {
              a || ((s = r), (i = !0), (s ??= "Unknown error"), (n = s + ""));
            } finally {
              ((t = null),
                (function () {
                  const t = { type: a ? "aborted" : i ? "error" : "ok" };
                  ("error" === t.type && (t.message = n),
                    self.postMessage([3, t]));
                })());
            }
          return;
        case 1:
          return (e?.(c), void (e = null));
        case 2:
          return void (a || (a = !0));
      }
      var s;
    }),
    (t = F),
    self.postMessage([0])));
