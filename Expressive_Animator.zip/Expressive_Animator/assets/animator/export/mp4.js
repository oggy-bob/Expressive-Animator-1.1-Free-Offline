let t,
  e,
  i,
  s,
  r = !1,
  a = !1;
function n(t) {
  ((a = !0), (t ??= "Unknown error"), (s = t + ""));
}
let o = new Uint8Array(8),
  h = new DataView(o.buffer);
const l = (t) => [((t % 256) + 256) % 256],
  c = (t) => (h.setUint16(0, t, !1), [o[0], o[1]]),
  u = (t) => (h.setUint32(0, t, !1), [o[1], o[2], o[3]]),
  d = (t) => (h.setUint32(0, t, !1), [o[0], o[1], o[2], o[3]]),
  p = (t) => (h.setUint8(0, t), h.setUint8(1, t << 8), [o[0], o[1]]),
  f = (t) => (
    h.setUint16(0, t, !1),
    h.setUint16(2, t << 16, !1),
    [o[0], o[1], o[2], o[3]]
  ),
  m = (t, e = !1) => {
    let i = Array(t.length)
      .fill(null)
      .map((e, i) => t.charCodeAt(i));
    return (e && i.push(0), i);
  },
  w = (t) => t && t[t.length - 1],
  k = (t, e, i = !0) => {
    let s = t * e;
    return i ? Math.round(s) : s;
  },
  g = 1e3,
  y = [65536, 0, 0, 0, 65536, 0, 0, 0, 1073741824].map(d),
  C = (t, e, i) => ({
    type: t,
    contents: e && new Uint8Array(e.flat(10)),
    children: i,
  }),
  v = (t, e, i, s, r) => C(t, [l(e), u(i), s ?? []], r),
  T = (t, e) => {
    let i = k(
        Math.max(
          0,
          ...e
            .filter((t) => t.samples.length > 0)
            .map((t) => w(t.samples).timestamp + w(t.samples).duration),
        ),
        g,
      ),
      s = Math.max(...e.map((t) => t.id)) + 1;
    return v("mvhd", 0, 0, [
      d(t),
      d(t),
      d(g),
      d(i),
      f(1),
      p(1),
      Array(10).fill(0),
      y,
      Array(24).fill(0),
      d(s),
    ]);
  },
  b = (t, e) => {
    let i = w(t.samples),
      s = k(i ? i.timestamp + i.duration : 0, g);
    return v("tkhd", 0, 3, [
      d(e),
      d(e),
      d(t.id),
      d(0),
      d(s),
      Array(8).fill(0),
      c(0),
      c(0),
      p("audio" === t.info.type ? 1 : 0),
      c(0),
      y,
      f("video" === t.info.type ? t.info.width : 0),
      f("video" === t.info.type ? t.info.height : 0),
    ]);
  },
  z = (t, e) =>
    C("mdia", null, [
      S(t, e),
      U("video" === t.info.type ? "vide" : "soun"),
      A(t),
    ]),
  S = (t, e) => {
    let i = w(t.samples),
      s = k(i ? i.timestamp + i.duration : 0, t.timescale);
    return v("mdhd", 0, 0, [d(e), d(e), d(t.timescale), d(s), c(21956), c(0)]);
  },
  U = (t) =>
    v("hdlr", 0, 0, [m("mhlr"), m(t), d(0), d(0), d(0), m("mp4-muxer-hdlr")]),
  A = (t) => C("minf", null, ["video" === t.info.type ? M() : x(), B(), F(t)]),
  M = () => v("vmhd", 0, 1, [c(0), c(0), c(0), c(0)]),
  x = () => v("smhd", 0, 0, [c(0), c(0)]),
  B = () => C("dinf", null, [L()]),
  L = () => v("dref", 0, 0, [d(1)], [D()]),
  D = () => v("url ", 0, 1),
  F = (t) => C("stbl", null, [P(t), O(t), N(t), H(t), W(t), q(t)]),
  P = (t) =>
    v(
      "stsd",
      0,
      0,
      [d(1)],
      [
        "video" === t.info.type
          ? V(
              "avc" === t.info.codec ? "avc1" : "hvc1",
              t,
              "avc" === t.info.codec ? E(t) : I(t),
            )
          : R("mp4a", t, $(t)),
      ],
    ),
  V = (t, e, i) =>
    C(
      t,
      [
        Array(6).fill(0),
        c(1),
        c(0),
        c(0),
        Array(12).fill(0),
        c(e.info.width),
        c(e.info.height),
        d(4718592),
        d(4718592),
        d(0),
        c(1),
        Array(32).fill(0),
        c(24),
        (h.setInt16(0, 65535, !1), [o[0], o[1]]),
      ],
      [i],
    ),
  E = (t) => t.codecPrivate && C("avcC", [...t.codecPrivate]),
  I = (t) => t.codecPrivate && C("hvcC", [...t.codecPrivate]),
  R = (t, e, i) =>
    C(
      t,
      [
        Array(6).fill(0),
        c(1),
        c(0),
        c(0),
        d(0),
        c(e.info.numberOfChannels),
        c(16),
        c(0),
        c(0),
        f(e.info.sampleRate),
      ],
      [i],
    ),
  $ = (t) =>
    v("esds", 0, 0, [
      d(58753152),
      l(32 + t.codecPrivate.byteLength),
      c(1),
      l(0),
      d(75530368),
      l(18 + t.codecPrivate.byteLength),
      l(64),
      l(21),
      u(0),
      d(130071),
      d(130071),
      d(92307584),
      l(t.codecPrivate.byteLength),
      ...t.codecPrivate,
      d(109084800),
      l(1),
      l(2),
    ]),
  O = (t) =>
    v("stts", 0, 0, [
      d(t.timeToSampleTable.length),
      t.timeToSampleTable.map((t) => [d(t.sampleCount), d(t.sampleDelta)]),
    ]),
  N = (t) => {
    if (t.samples.every((t) => "key" === t.type)) return null;
    let e = [...t.samples.entries()].filter(([, t]) => "key" === t.type);
    return v("stss", 0, 0, [d(e.length), e.map(([t]) => d(t + 1))]);
  },
  H = (t) =>
    v("stsc", 0, 0, [
      d(t.compactlyCodedChunkTable.length),
      t.compactlyCodedChunkTable.map((t) => [
        d(t.firstChunk),
        d(t.samplesPerChunk),
        d(1),
      ]),
    ]),
  W = (t) =>
    v("stsz", 0, 0, [
      d(0),
      d(t.samples.length),
      t.samples.map((t) => d(t.size)),
    ]),
  q = (t) =>
    t.writtenChunks.length > 0 && w(t.writtenChunks).offset >= 2 ** 32
      ? v("co64", 0, 0, [
          d(t.writtenChunks.length),
          t.writtenChunks.map((t) => {
            return (
              (e = t.offset),
              h.setUint32(0, Math.floor(e / 2 ** 32), !1),
              h.setUint32(4, e, !1),
              [o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7]]
            );
            var e;
          }),
        ])
      : v("stco", 0, 0, [
          d(t.writtenChunks.length),
          t.writtenChunks.map((t) => d(t.offset)),
        ]);
class j {
  constructor() {
    this.buffer = null;
  }
}
class G {
  constructor(t, e, i) {
    ((this.onData = t), (this.onDone = e), (this.options = i));
  }
}
class J {
  constructor(t, e) {
    ((this.stream = t), (this.options = e));
  }
}
class K {
  constructor() {
    ((this.pos = 0),
      (this.#t = new Uint8Array(8)),
      (this.#e = new DataView(this.#t.buffer)),
      (this.offsets = new WeakMap()));
  }
  #t;
  #e;
  seek(t) {
    this.pos = t;
  }
  writeU32(t) {
    (this.#e.setUint32(0, t, !1), this.write(this.#t.subarray(0, 4)));
  }
  writeU64(t) {
    (this.#e.setUint32(0, Math.floor(t / 2 ** 32), !1),
      this.#e.setUint32(4, t, !1),
      this.write(this.#t.subarray(0, 8)));
  }
  writeAscii(t) {
    for (let e = 0; e < t.length; e++)
      (this.#e.setUint8(e % 8, t.charCodeAt(e)),
        e % 8 == 7 && this.write(this.#t));
    t.length % 8 != 0 && this.write(this.#t.subarray(0, t.length % 8));
  }
  writeBox(t) {
    if ((this.offsets.set(t, this.pos), t.contents && !t.children))
      (this.writeBoxHeader(t, t.size ?? t.contents.byteLength + 8),
        this.write(t.contents));
    else {
      let e = this.pos;
      if (
        (this.writeBoxHeader(t, 0),
        t.contents && this.write(t.contents),
        t.children)
      )
        for (let e of t.children) e && this.writeBox(e);
      let i = this.pos,
        s = t.size ?? i - e;
      (this.seek(e), this.writeBoxHeader(t, s), this.seek(i));
    }
  }
  writeBoxHeader(t, e) {
    (this.writeU32(t.largeSize ? 1 : e),
      this.writeAscii(t.type),
      t.largeSize && this.writeU64(e));
  }
  patchBox(t) {
    let e = this.pos;
    (this.seek(this.offsets.get(t)), this.writeBox(t), this.seek(e));
  }
}
class Q extends K {
  #i;
  #s = new ArrayBuffer(65536);
  #r = new Uint8Array(this.#s);
  constructor(t) {
    (super(), (this.#i = t));
  }
  #a(t) {
    let e = this.#s.byteLength;
    for (; e < t; ) e *= 2;
    if (e === this.#s.byteLength) return;
    let i = new ArrayBuffer(e),
      s = new Uint8Array(i);
    (s.set(this.#r, 0), (this.#s = i), (this.#r = s));
  }
  write(t) {
    (this.#a(this.pos + t.byteLength),
      this.#r.set(t, this.pos),
      (this.pos += t.byteLength));
  }
  finalize() {
    (this.#a(this.pos), (this.#i.buffer = this.#s.slice(0, this.pos)));
  }
}
class X extends K {
  #i;
  #n = [];
  constructor(t) {
    (super(), (this.#i = t));
  }
  write(t) {
    (this.#n.push({ data: t.slice(), start: this.pos }),
      (this.pos += t.byteLength));
  }
  flush() {
    if (0 === this.#n.length) return;
    let t = [],
      e = [...this.#n].sort((t, e) => t.start - e.start);
    t.push({ start: e[0].start, size: e[0].data.byteLength });
    for (let i = 1; i < e.length; i++) {
      let s = t[t.length - 1],
        r = e[i];
      r.start <= s.start + s.size
        ? (s.size = Math.max(s.size, r.start + r.data.byteLength - s.start))
        : t.push({ start: r.start, size: r.data.byteLength });
    }
    for (let e of t) {
      e.data = new Uint8Array(e.size);
      for (let t of this.#n)
        e.start <= t.start &&
          t.start < e.start + e.size &&
          e.data.set(t.data, t.start - e.start);
      this.#i.onData(e.data, e.start);
    }
    this.#n.length = 0;
  }
  finalize() {
    this.#i.onDone?.();
  }
}
class Y extends K {
  #i;
  #o;
  #h = [];
  constructor(t) {
    if (
      (super(),
      (this.#i = t),
      (this.#o = t.options?.chunkSize ?? 16777216),
      !Number.isInteger(this.#o) || this.#o < 1024)
    )
      throw new Error(
        "Invalid StreamTarget options: chunkSize must be an integer not smaller than 1024.",
      );
  }
  write(t) {
    (this.#l(t, this.pos), this.#c(), (this.pos += t.byteLength));
  }
  #l(t, e) {
    let i = this.#h.findIndex((t) => t.start <= e && e < t.start + this.#o);
    -1 === i && (i = this.#u(e));
    let s = this.#h[i],
      r = e - s.start,
      a = t.subarray(0, Math.min(this.#o - r, t.byteLength));
    s.data.set(a, r);
    let n = { start: r, end: r + a.byteLength };
    if (
      (this.#d(s, n),
      0 === s.written[0].start &&
        s.written[0].end === this.#o &&
        (s.shouldFlush = !0),
      this.#h.length > 2)
    ) {
      for (let t = 0; t < this.#h.length - 1; t++) this.#h[t].shouldFlush = !0;
      this.#c();
    }
    a.byteLength < t.byteLength &&
      this.#l(t.subarray(a.byteLength), e + a.byteLength);
  }
  #d(t, e) {
    let i = 0,
      s = t.written.length - 1,
      r = -1;
    for (; i <= s; ) {
      let a = Math.floor(i + (s - i + 1) / 2);
      t.written[a].start <= e.start ? ((i = a + 1), (r = a)) : (s = a - 1);
    }
    for (
      t.written.splice(r + 1, 0, e),
        (-1 === r || t.written[r].end < e.start) && r++;
      r < t.written.length - 1 && t.written[r].end >= t.written[r + 1].start;
    )
      ((t.written[r].end = Math.max(t.written[r].end, t.written[r + 1].end)),
        t.written.splice(r + 1, 1));
  }
  #u(t) {
    let e = {
      start: Math.floor(t / this.#o) * this.#o,
      data: new Uint8Array(this.#o),
      written: [],
      shouldFlush: !1,
    };
    return (
      this.#h.push(e),
      this.#h.sort((t, e) => t.start - e.start),
      this.#h.indexOf(e)
    );
  }
  #c(t = !1) {
    for (let e = 0; e < this.#h.length; e++) {
      let i = this.#h[e];
      if (i.shouldFlush || t) {
        for (let t of i.written)
          this.#i.onData(i.data.subarray(t.start, t.end), i.start + t.start);
        this.#h.splice(e--, 1);
      }
    }
  }
  finalize() {
    (this.#c(!0), this.#i.onDone?.());
  }
}
class Z extends Y {
  constructor(t) {
    super(
      new G(
        (e, i) => t.stream.write({ type: "write", data: e, position: i }),
        void 0,
        { chunkSize: t.options?.chunkSize },
      ),
    );
  }
}
const _ = ["avc", "hevc"],
  tt = ["aac"],
  et = ["strict", "offset"];
class it {
  #p;
  #f;
  #m;
  #w = null;
  #k = null;
  #g = Math.floor(Date.now() / 1e3) + 2082844800;
  #y = !1;
  constructor(t) {
    if (
      (this.#C(t),
      (this.target = t.target),
      (this.#p = { firstTimestampBehavior: "strict", ...t }),
      t.target instanceof j)
    )
      this.#f = new Q(t.target);
    else if (t.target instanceof G)
      this.#f = t.target.options?.chunked ? new Y(t.target) : new X(t.target);
    else {
      if (!(t.target instanceof J))
        throw new Error(`Invalid target: ${t.target}`);
      this.#f = new Z(t.target);
    }
  }
  init() {
    (this.#v(), this.#T());
  }
  #C(t) {
    if (t.video && !_.includes(t.video.codec))
      throw new Error(`Unsupported video codec: ${t.video.codec}`);
    if (t.audio && !tt.includes(t.audio.codec))
      throw new Error(`Unsupported audio codec: ${t.audio.codec}`);
    if (t.firstTimestampBehavior && !et.includes(t.firstTimestampBehavior))
      throw new Error(
        `Invalid first timestamp behavior: ${t.firstTimestampBehavior}`,
      );
  }
  #v() {
    let t = "hevc" === this.#p.video?.codec;
    (this.#f.writeBox(
      ((t) =>
        C(
          "ftyp",
          t
            ? [m("isom"), d(0), m("iso4"), m("hvc1")]
            : [m("isom"), d(0), m("isom"), m("avc1"), m("mp41")],
        ))(t),
    ),
      (this.#m = { type: "mdat", largeSize: !0 }),
      this.#f.writeBox(this.#m),
      this.#b());
  }
  #T() {
    if (
      (this.#p.video &&
        (this.#w = {
          id: 1,
          info: {
            type: "video",
            codec: this.#p.video.codec,
            width: this.#p.video.width,
            height: this.#p.video.height,
          },
          timescale: 720,
          codecPrivate: new Uint8Array(0),
          samples: [],
          writtenChunks: [],
          currentChunk: null,
          firstTimestamp: void 0,
          lastTimestamp: -1,
          timeToSampleTable: [],
          lastTimescaleUnits: null,
          compactlyCodedChunkTable: [],
        }),
      this.#p.audio)
    ) {
      let t = this.#z(
        2,
        this.#p.audio.sampleRate,
        this.#p.audio.numberOfChannels,
      );
      this.#k = {
        id: this.#p.video ? 2 : 1,
        info: {
          type: "audio",
          codec: this.#p.audio.codec,
          numberOfChannels: this.#p.audio.numberOfChannels,
          sampleRate: this.#p.audio.sampleRate,
        },
        timescale: this.#p.audio.sampleRate,
        codecPrivate: t,
        samples: [],
        writtenChunks: [],
        currentChunk: null,
        firstTimestamp: void 0,
        lastTimestamp: -1,
        timeToSampleTable: [],
        lastTimescaleUnits: null,
        compactlyCodedChunkTable: [],
      };
    }
  }
  #z(t, e, i) {
    let s = [
        96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025,
        8e3, 7350,
      ].indexOf(e),
      r = i,
      a = "";
    ((a += t.toString(2).padStart(5, "0")),
      (a += s.toString(2).padStart(4, "0")),
      15 === s && (a += e.toString(2).padStart(24, "0")),
      (a += r.toString(2).padStart(4, "0")));
    let n = 8 * Math.ceil(a.length / 8);
    a = a.padEnd(n, "0");
    let o = new Uint8Array(a.length / 8);
    for (let t = 0; t < a.length; t += 8)
      o[t / 8] = parseInt(a.slice(t, t + 8), 2);
    return o;
  }
  addVideoChunk(t, e, i) {
    let s = new Uint8Array(t.byteLength);
    (t.copyTo(s),
      this.addVideoChunkRaw(s, t.type, i ?? t.timestamp, t.duration, e));
  }
  addVideoChunkRaw(t, e, i, s, r) {
    if ((this.#S(), !this.#p.video))
      throw new Error("No video track declared.");
    this.#U(this.#w, t, e, i, s, r);
  }
  addAudioChunk(t, e, i) {
    let s = new Uint8Array(t.byteLength);
    (t.copyTo(s),
      this.addAudioChunkRaw(s, t.type, i ?? t.timestamp, t.duration, e));
  }
  addAudioChunkRaw(t, e, i, s, r) {
    if ((this.#S(), !this.#p.audio))
      throw new Error("No audio track declared.");
    this.#U(this.#k, t, e, i, s, r);
  }
  #U(t, e, i, s, r, a) {
    let n = s / 1e6,
      o = r / 1e6;
    if (
      (void 0 === t.firstTimestamp && (t.firstTimestamp = n),
      (n = this.#A(n, t)),
      (!t.currentChunk || n - t.currentChunk.startTimestamp >= 0.5) &&
        (t.currentChunk && this.#M(t),
        (t.currentChunk = {
          startTimestamp: n,
          sampleData: [],
          sampleCount: 0,
        })),
      t.currentChunk.sampleData.push(e),
      t.currentChunk.sampleCount++,
      a?.decoderConfig?.description &&
        (t.codecPrivate = new Uint8Array(a.decoderConfig.description)),
      t.samples.push({
        timestamp: n,
        duration: o,
        size: e.byteLength,
        type: i,
      }),
      null !== t.lastTimescaleUnits)
    ) {
      let e = k(n, t.timescale, !1),
        i = Math.round(e - t.lastTimescaleUnits);
      t.lastTimescaleUnits += i;
      let s = w(t.timeToSampleTable);
      1 === s.sampleCount
        ? ((s.sampleDelta = i), s.sampleCount++)
        : s.sampleDelta === i
          ? s.sampleCount++
          : (s.sampleCount--,
            t.timeToSampleTable.push({ sampleCount: 2, sampleDelta: i }));
    } else
      ((t.lastTimescaleUnits = 0),
        t.timeToSampleTable.push({
          sampleCount: 1,
          sampleDelta: k(o, t.timescale),
        }));
  }
  #A(t, e) {
    if (
      "strict" === this.#p.firstTimestampBehavior &&
      -1 === e.lastTimestamp &&
      0 !== t
    )
      throw new Error(
        `The first chunk for your media track must have a timestamp of 0 (received ${t}). Non-zero first timestamps are often caused by directly piping frames or audio data from a MediaStreamTrack into the encoder. Their timestamps are typically relative to the age of the document, which is probably what you want.\n\nIf you want to offset all timestamps of a track such that the first one is zero, set firstTimestampBehavior: 'offset' in the options.\n`,
      );
    if (
      ("offset" === this.#p.firstTimestampBehavior && (t -= e.firstTimestamp),
      t < e.lastTimestamp)
    )
      throw new Error(
        `Timestamps must be monotonically increasing (went from ${1e6 * e.lastTimestamp} to ${1e6 * t}).`,
      );
    return t;
  }
  #M(t) {
    if (t.currentChunk) {
      t.currentChunk.offset = this.#f.pos;
      for (let e of t.currentChunk.sampleData) this.#f.write(e);
      ((t.currentChunk.sampleData = null),
        (0 !== t.compactlyCodedChunkTable.length &&
          w(t.compactlyCodedChunkTable).samplesPerChunk ===
            t.currentChunk.sampleCount) ||
          t.compactlyCodedChunkTable.push({
            firstChunk: t.writtenChunks.length + 1,
            samplesPerChunk: t.currentChunk.sampleCount,
          }),
        t.writtenChunks.push(t.currentChunk),
        this.#b());
    }
  }
  #b() {
    this.#f instanceof X && this.#f.flush();
  }
  #S() {
    if (this.#y)
      throw new Error(
        "Cannot add new video or audio chunks after the file has been finalized.",
      );
  }
  finalize() {
    (this.#w && this.#M(this.#w), this.#k && this.#M(this.#k));
    let t = this.#f.offsets.get(this.#m),
      e = this.#f.pos - t;
    ((this.#m.size = e), this.#f.patchBox(this.#m));
    let i =
      ((s = [this.#w, this.#k].filter(Boolean)),
      (r = this.#g),
      C("moov", null, [
        T(r, s),
        ...s.map((t) => ((t, e) => C("trak", null, [b(t, e), z(t, e)]))(t, r)),
      ]));
    var s, r;
    (this.#f.writeBox(i), this.#b(), this.#f.finalize(), (this.#y = !0));
  }
}
class st {
  #x = null;
  #B;
  #L;
  constructor(t, e) {
    ((this.#L = t), (this.#B = e));
  }
  async fetch(t) {
    const i = await (function (t) {
      return new Promise((i) => {
        ((e = i), self.postMessage([1, t]));
      });
    })(t);
    return void 0 === i
      ? this.#x
      : (this.#D(), this.#L ? (this.#x = await this.#L(i)) : (this.#x = i));
  }
  #D() {
    null != this.#x && (this.#B?.(this.#x), (this.#x = null));
  }
  dispose() {
    (this.#D(), (this.#L = this.#B = null));
  }
}
function rt(t) {
  t.close();
}
function at(t, e) {
  const i = t.size.width * t.size.height;
  for (const [s, r] of e) if (i <= s) return nt(t) <= 30 ? r[0] : r[1];
  return 0;
}
function nt(t) {
  return t.speed ? t.fps / t.speed : t.fps;
}
const ot = new Map([
    [414720, [4, 10]],
    [921600, [14, 20]],
    [1310720, [20, 20]],
    [2097152, [20, 50]],
    [2228224, [50, 135]],
    [5652480, [135, 240]],
    [9437184, [240, 240]],
    [35651584, [240, 480]],
  ]),
  ht = new Map([
    [414720, [22, 30]],
    [921600, [31, 32]],
    [1310720, [32, 40]],
    [2097152, [40, 41]],
    [2228224, [41, 50]],
    [5652480, [50, 51]],
    [9437184, [51, 52]],
    [35651584, [60, 61]],
  ]);
function lt(t) {
  return "avc" === t.codec
    ? `avc1.6400${at(t, ht).toString(16).padStart(2, "0").toUpperCase()}`
    : t.codec;
}
function ct(t) {
  return (function (t, e) {
    return Math.round(1e6 * (t.quality || 1) * at(t, e));
  })(t, ot);
}
var ut;
((ut = async function (t, e) {
  const i = {
    codec: lt(t),
    bitrate: ct(t),
    framerate: nt(t),
    width: t.size.width,
    height: t.size.height,
    latencyMode: "quality",
    bitrateMode: "constant",
    hardwareAcceleration: "no-preference",
  };
  if (
    !(await (async function (t) {
      return (await VideoEncoder.isConfigSupported(t))?.supported;
    })(i))
  )
    throw new Error(`Cannot create video encoder ${i.codec}`);
  const s = await e.createWritable();
  try {
    await (async function (t, e, i) {
      const s = new it({
          target: new G(
            (t, e) => {
              i.write({ data: t, position: e, type: "write" });
            },
            void 0,
            { chunked: !1 },
          ),
          video: { width: t.size.width, height: t.size.height, codec: "avc" },
          firstTimestampBehavior: "offset",
        }),
        o = new VideoEncoder({
          output: (t, e) => {
            s.addVideoChunk(t, e);
          },
          error: n,
        });
      return (
        o.configure(e),
        s.init(),
        (async function (t, e, i, s) {
          const n = new st(null, rt),
            o = { keyFrame: !1 };
          for (const e of (function* (t) {
            const e = t.repeat || 1,
              i = t.startTime || 0,
              s = t.speed || 1,
              n = t.fps * (s < 1 ? 1 / s : 1),
              o = 1e3 / n,
              h = Math.ceil(t.duration / o);
            let l = 0,
              c = !t.reverse;
            const u = e * h,
              d = t.keyframe || 0,
              p = {
                time: 0,
                frame: 0,
                relativeFrame: 0,
                timestamp: 0,
                keyframe: !1,
                progress: 0,
                fps: n,
                totalRepeats: e,
                totalFrames: u,
              };
            for (let n = 0; n < e; n++) {
              for (let t = l; t < h; t++) {
                if (r || a) return p;
                ((p.relativeFrame = c ? t : h - 1 - t),
                  (p.time = i + Math.round(p.relativeFrame * o)),
                  (p.frame = n * h + t),
                  (p.timestamp = 1e3 * Math.round((p.frame * o) / s)),
                  (p.keyframe = d
                    ? !(p.frame % d)
                    : t === l || !(p.frame % 120)),
                  (p.progress = p.frame / u),
                  yield p);
              }
              t.alternate && ((c = !c), (l = 1));
            }
            return p;
          })(t)) {
            ((h = e.progress), self.postMessage([2, [h, void 0]]));
            const t = await n.fetch(e.time),
              r = new VideoFrame(t, { timestamp: e.timestamp });
            ((o.keyFrame = e.keyframe), i.encode(r, o), s, r.close());
          }
          var h;
          (n.dispose(),
            r
              ? (i.reset(), s?.reset())
              : a || (await i.flush(), await s?.flush(), e && (await e())),
            "closed" !== i.state && i.close());
        })(t, () => s.finalize(), o)
      );
    })(t, i, s);
  } finally {
    await s.close();
  }
}),
  t ||
    ((r = a = !1),
    (s = null),
    (i = null),
    (self.onmessage = async function (i) {
      const [o, h] = i.data;
      switch (o) {
        case 0:
          if (t)
            try {
              await t(h[0], h[1]);
            } catch (i) {
              r || n(i);
            } finally {
              ((t = null),
                (function () {
                  const t = { type: r ? "aborted" : a ? "error" : "ok" };
                  ("error" === t.type && (t.message = s),
                    self.postMessage([3, t]));
                })());
            }
          return;
        case 1:
          return (e?.(h), void (e = null));
        case 2:
          return void (r || (r = !0));
      }
    }),
    (t = ut),
    self.postMessage([0])));
