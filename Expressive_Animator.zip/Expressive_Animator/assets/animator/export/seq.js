let e,
  t,
  a,
  r,
  n = !1,
  s = !1;
function i(e, t) {
  self.postMessage([2, [e, t]]);
}
class o {
  #e = null;
  #t;
  #a;
  constructor(e, t) {
    ((this.#a = e), (this.#t = t));
  }
  async fetch(e) {
    const a = await (function (e) {
      return new Promise((a) => {
        ((t = a), self.postMessage([1, e]));
      });
    })(e);
    return void 0 === a
      ? this.#e
      : (this.#r(), this.#a ? (this.#e = await this.#a(a)) : (this.#e = a));
  }
  #r() {
    null != this.#e && (this.#t?.(this.#e), (this.#e = null));
  }
  dispose() {
    (this.#r(), (this.#a = this.#t = null));
  }
}
async function c(e) {
  return e instanceof ArrayBuffer
    ? e
    : ArrayBuffer.isView(e)
      ? e.buffer
      : e instanceof Blob
        ? e.arrayBuffer()
        : null;
}
async function l(e, t) {
  const a = await e.createWritable();
  (await a.write(t), await a.close());
}
async function f(e, t) {
  return (await e.getFile())
    .stream()
    .pipeTo(await t.createWritable(), {
      signal: (a ??= new AbortController()).signal,
    });
}
var u;
((u = async function (e, t) {
  let a;
  a = e.image
    ? (function (e, t, a) {
        const r = new OffscreenCanvas(e, t),
          n = r.getContext("bitmaprenderer");
        return new o(
          async (e) => (
            n.transferFromImageBitmap(e),
            e.close(),
            (await r.convertToBlob(a)).arrayBuffer()
          ),
        );
      })(e.size.width, e.size.height, e.image)
    : new o(c);
  try {
    await (async function (e, t, a) {
      e.clean &&
        (i(-1, "Cleaning directory..."),
        await (async function (e) {
          const t = [];
          for await (const a of e.keys())
            t.push(e.removeEntry(a, { recursive: !0 }));
          await Promise.all(t);
        })(t),
        i(-1, "Exporting..."));
      const r = (
          (e.repeat || 1) *
          Math.ceil(
            (e.duration *
              (function (e) {
                return e.speed ? e.fps / e.speed : e.fps;
              })(e)) /
              1e3,
          )
        ).toString().length,
        o = (e.prefix ?? "").replaceAll(/[^A-Z0-9-_. ]/gi, ""),
        c = (a) => {
          const n = `${o}${(a + 1).toString().padStart(r, "0")}.${e.extension}`;
          return t.getFileHandle(n, { create: !0 });
        },
        u = new Map();
      for (const t of (function* (e) {
        const t = e.repeat || 1,
          a = e.startTime || 0,
          r = e.speed || 1,
          i = e.fps * (r < 1 ? 1 / r : 1),
          o = 1e3 / i,
          c = Math.ceil(e.duration / o);
        let l = 0,
          f = !e.reverse;
        const u = t * c,
          m = e.keyframe || 0,
          p = {
            time: 0,
            frame: 0,
            relativeFrame: 0,
            timestamp: 0,
            keyframe: !1,
            progress: 0,
            fps: i,
            totalRepeats: t,
            totalFrames: u,
          };
        for (let i = 0; i < t; i++) {
          for (let e = l; e < c; e++) {
            if (n || s) return p;
            ((p.relativeFrame = f ? e : c - 1 - e),
              (p.time = a + Math.round(p.relativeFrame * o)),
              (p.frame = i * c + e),
              (p.timestamp = 1e3 * Math.round((p.frame * o) / r)),
              (p.keyframe = m ? !(p.frame % m) : e === l || !(p.frame % 120)),
              (p.progress = p.frame / u),
              yield p);
          }
          e.alternate && ((f = !f), (l = 1));
        }
        return p;
      })(e)) {
        i(t.progress);
        const e = await c(t.frame);
        u.has(t.relativeFrame)
          ? await f(u.get(t.relativeFrame), e)
          : (await l(e, await a.fetch(t.time)), u.set(t.relativeFrame, e));
      }
      u.clear();
    })(e, t, a);
  } finally {
    a.dispose();
  }
}),
  e ||
    ((n = s = !1),
    (r = null),
    (a = null),
    (self.onmessage = async function (i) {
      const [o, c] = i.data;
      switch (o) {
        case 0:
          if (e)
            try {
              await e(c[0], c[1]);
            } catch (i) {
              n || ((l = i), (s = !0), (l ??= "Unknown error"), (r = l + ""));
            } finally {
              ((e = null),
                (function () {
                  const e = { type: n ? "aborted" : s ? "error" : "ok" };
                  ("error" === e.type && (e.message = r),
                    self.postMessage([3, e]));
                })());
            }
          return;
        case 1:
          return (t?.(c), void (t = null));
        case 2:
          return void (n || ((n = !0), a?.abort("Client aborted")));
      }
      var l;
    }),
    (e = u),
    self.postMessage([0])));
