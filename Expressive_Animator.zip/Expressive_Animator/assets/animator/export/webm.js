let t,
  e,
  i,
  s,
  r = !1,
  a = !1;
function n(t) {
  ((a = !0), (t ??= "Unknown error"), (s = t + ""));
}
class o {
  #t = null;
  #e;
  #i;
  constructor(t, e) {
    ((this.#i = t), (this.#e = e));
  }
  async fetch(t) {
    const i = await (function (t) {
      return new Promise((i) => {
        ((e = i), self.postMessage([1, t]));
      });
    })(t);
    return void 0 === i
      ? this.#t
      : (this.#s(), this.#i ? (this.#t = await this.#i(i)) : (this.#t = i));
  }
  #s() {
    null != this.#t && (this.#e?.(this.#t), (this.#t = null));
  }
  dispose() {
    (this.#s(), (this.#i = this.#e = null));
  }
}
function h(t) {
  t.close();
}
function d(t, e) {
  const i = t.size.width * t.size.height;
  for (const [s, r] of e) if (i <= s) return l(t) <= 30 ? r[0] : r[1];
  return 0;
}
function l(t) {
  return t.speed ? t.fps / t.speed : t.fps;
}
class u {
  constructor(t) {
    this.value = t;
  }
}
class c {
  constructor(t) {
    this.value = t;
  }
}
var p;
!(function (t) {
  ((t[(t.EBML = 440786851)] = "EBML"),
    (t[(t.EBMLVersion = 17030)] = "EBMLVersion"),
    (t[(t.EBMLReadVersion = 17143)] = "EBMLReadVersion"),
    (t[(t.EBMLMaxIDLength = 17138)] = "EBMLMaxIDLength"),
    (t[(t.EBMLMaxSizeLength = 17139)] = "EBMLMaxSizeLength"),
    (t[(t.DocType = 17026)] = "DocType"),
    (t[(t.DocTypeVersion = 17031)] = "DocTypeVersion"),
    (t[(t.DocTypeReadVersion = 17029)] = "DocTypeReadVersion"),
    (t[(t.SeekHead = 290298740)] = "SeekHead"),
    (t[(t.Seek = 19899)] = "Seek"),
    (t[(t.SeekID = 21419)] = "SeekID"),
    (t[(t.SeekPosition = 21420)] = "SeekPosition"),
    (t[(t.Duration = 17545)] = "Duration"),
    (t[(t.Info = 357149030)] = "Info"),
    (t[(t.TimestampScale = 2807729)] = "TimestampScale"),
    (t[(t.MuxingApp = 19840)] = "MuxingApp"),
    (t[(t.WritingApp = 22337)] = "WritingApp"),
    (t[(t.Tracks = 374648427)] = "Tracks"),
    (t[(t.TrackEntry = 174)] = "TrackEntry"),
    (t[(t.TrackNumber = 215)] = "TrackNumber"),
    (t[(t.TrackUID = 29637)] = "TrackUID"),
    (t[(t.TrackType = 131)] = "TrackType"),
    (t[(t.CodecID = 134)] = "CodecID"),
    (t[(t.CodecPrivate = 25506)] = "CodecPrivate"),
    (t[(t.DefaultDuration = 2352003)] = "DefaultDuration"),
    (t[(t.Video = 224)] = "Video"),
    (t[(t.PixelWidth = 176)] = "PixelWidth"),
    (t[(t.PixelHeight = 186)] = "PixelHeight"),
    (t[(t.Void = 236)] = "Void"),
    (t[(t.Audio = 225)] = "Audio"),
    (t[(t.SamplingFrequency = 181)] = "SamplingFrequency"),
    (t[(t.Channels = 159)] = "Channels"),
    (t[(t.BitDepth = 25188)] = "BitDepth"),
    (t[(t.Segment = 408125543)] = "Segment"),
    (t[(t.SimpleBlock = 163)] = "SimpleBlock"),
    (t[(t.Cluster = 524531317)] = "Cluster"),
    (t[(t.Timestamp = 231)] = "Timestamp"),
    (t[(t.Cues = 475249515)] = "Cues"),
    (t[(t.CuePoint = 187)] = "CuePoint"),
    (t[(t.CueTime = 179)] = "CueTime"),
    (t[(t.CueTrackPositions = 183)] = "CueTrackPositions"),
    (t[(t.CueTrack = 247)] = "CueTrack"),
    (t[(t.CueClusterPosition = 241)] = "CueClusterPosition"),
    (t[(t.Colour = 21936)] = "Colour"),
    (t[(t.MatrixCoefficients = 21937)] = "MatrixCoefficients"),
    (t[(t.TransferCharacteristics = 21946)] = "TransferCharacteristics"),
    (t[(t.Primaries = 21947)] = "Primaries"),
    (t[(t.Range = 21945)] = "Range"),
    (t[(t.AlphaMode = 21440)] = "AlphaMode"),
    (t[(t.BlockGroup = 160)] = "BlockGroup"),
    (t[(t.Block = 161)] = "Block"),
    (t[(t.BlockAdditions = 30113)] = "BlockAdditions"),
    (t[(t.BlockMore = 166)] = "BlockMore"),
    (t[(t.BlockAddID = 238)] = "BlockAddID"),
    (t[(t.BlockAdditional = 165)] = "BlockAdditional"),
    (t[(t.BlockDuration = 155)] = "BlockDuration"));
})(p || (p = {}));
const f = (t) =>
    t < 256
      ? 1
      : t < 65536
        ? 2
        : t < 1 << 24
          ? 3
          : t < 2 ** 32
            ? 4
            : t < 2 ** 40
              ? 5
              : 6,
  m = (t, e, i) => {
    let s = 0;
    for (let r = e; r < i; r++) {
      let e = 7 - (7 & r);
      ((s <<= 1), (s |= (t[Math.floor(r / 8)] & (1 << e)) >> e));
    }
    return s;
  };
class w {
  constructor() {
    this.buffer = null;
  }
}
class k {
  constructor(t, e, i) {
    ((this.onData = t), (this.onDone = e), (this.options = i));
  }
}
class g {
  constructor(t, e) {
    ((this.stream = t), (this.options = e));
  }
}
class C {
  constructor() {
    ((this.pos = 0),
      (this.#r = new Uint8Array(8)),
      (this.#a = new DataView(this.#r.buffer)),
      (this.offsets = new WeakMap()),
      (this.dataOffsets = new WeakMap()));
  }
  #r;
  #a;
  seek(t) {
    this.pos = t;
  }
  #n(t) {
    (this.#a.setUint8(0, t), this.write(this.#r.subarray(0, 1)));
  }
  #o(t) {
    (this.#a.setFloat32(0, t, !1), this.write(this.#r.subarray(0, 4)));
  }
  #h(t) {
    (this.#a.setFloat64(0, t, !1), this.write(this.#r));
  }
  #d(t, e = f(t)) {
    let i = 0;
    switch (e) {
      case 6:
        this.#a.setUint8(i++, (t / 2 ** 40) | 0);
      case 5:
        this.#a.setUint8(i++, (t / 2 ** 32) | 0);
      case 4:
        this.#a.setUint8(i++, t >> 24);
      case 3:
        this.#a.setUint8(i++, t >> 16);
      case 2:
        this.#a.setUint8(i++, t >> 8);
      case 1:
        this.#a.setUint8(i++, t);
        break;
      default:
        throw new Error("Bad UINT size " + e);
    }
    this.write(this.#r.subarray(0, i));
  }
  writeEBMLVarInt(
    t,
    e = ((t) => {
      if (t < 127) return 1;
      if (t < 16383) return 2;
      if (t < 2097151) return 3;
      if (t < 268435455) return 4;
      if (t < 2 ** 35 - 1) return 5;
      if (t < 2 ** 42 - 1) return 6;
      throw new Error("EBML VINT size not supported " + t);
    })(t),
  ) {
    let i = 0;
    switch (e) {
      case 1:
        this.#a.setUint8(i++, 128 | t);
        break;
      case 2:
        (this.#a.setUint8(i++, 64 | (t >> 8)), this.#a.setUint8(i++, t));
        break;
      case 3:
        (this.#a.setUint8(i++, 32 | (t >> 16)),
          this.#a.setUint8(i++, t >> 8),
          this.#a.setUint8(i++, t));
        break;
      case 4:
        (this.#a.setUint8(i++, 16 | (t >> 24)),
          this.#a.setUint8(i++, t >> 16),
          this.#a.setUint8(i++, t >> 8),
          this.#a.setUint8(i++, t));
        break;
      case 5:
        (this.#a.setUint8(i++, 8 | ((t / 2 ** 32) & 7)),
          this.#a.setUint8(i++, t >> 24),
          this.#a.setUint8(i++, t >> 16),
          this.#a.setUint8(i++, t >> 8),
          this.#a.setUint8(i++, t));
        break;
      case 6:
        (this.#a.setUint8(i++, 4 | ((t / 2 ** 40) & 3)),
          this.#a.setUint8(i++, (t / 2 ** 32) | 0),
          this.#a.setUint8(i++, t >> 24),
          this.#a.setUint8(i++, t >> 16),
          this.#a.setUint8(i++, t >> 8),
          this.#a.setUint8(i++, t));
        break;
      default:
        throw new Error("Bad EBML VINT size " + e);
    }
    this.write(this.#r.subarray(0, i));
  }
  #l(t) {
    this.write(new Uint8Array(t.split("").map((t) => t.charCodeAt(0))));
  }
  writeEBML(t) {
    if (null !== t)
      if (t instanceof Uint8Array) this.write(t);
      else if (Array.isArray(t)) for (let e of t) this.writeEBML(e);
      else if (
        (this.offsets.set(t, this.pos), this.#d(t.id), Array.isArray(t.data))
      ) {
        let e = this.pos,
          i = -1 === t.size ? 1 : (t.size ?? 4);
        -1 === t.size ? this.#n(255) : this.seek(this.pos + i);
        let s = this.pos;
        if (
          (this.dataOffsets.set(t, s), this.writeEBML(t.data), -1 !== t.size)
        ) {
          let t = this.pos - s,
            r = this.pos;
          (this.seek(e), this.writeEBMLVarInt(t, i), this.seek(r));
        }
      } else if ("number" == typeof t.data) {
        let e = t.size ?? f(t.data);
        (this.writeEBMLVarInt(e), this.#d(t.data, e));
      } else
        "string" == typeof t.data
          ? (this.writeEBMLVarInt(t.data.length), this.#l(t.data))
          : t.data instanceof Uint8Array
            ? (this.writeEBMLVarInt(t.data.byteLength, t.size),
              this.write(t.data))
            : t.data instanceof u
              ? (this.writeEBMLVarInt(4), this.#o(t.data.value))
              : t.data instanceof c &&
                (this.writeEBMLVarInt(8), this.#h(t.data.value));
  }
}
class y extends C {
  #u;
  #c = new ArrayBuffer(65536);
  #p = new Uint8Array(this.#c);
  constructor(t) {
    (super(), (this.#u = t));
  }
  #f(t) {
    let e = this.#c.byteLength;
    for (; e < t; ) e *= 2;
    if (e === this.#c.byteLength) return;
    let i = new ArrayBuffer(e),
      s = new Uint8Array(i);
    (s.set(this.#p, 0), (this.#c = i), (this.#p = s));
  }
  write(t) {
    (this.#f(this.pos + t.byteLength),
      this.#p.set(t, this.pos),
      (this.pos += t.byteLength));
  }
  finalize() {
    (this.#f(this.pos), (this.#u.buffer = this.#c.slice(0, this.pos)));
  }
}
class T extends C {
  #u;
  #m = [];
  #w = 0;
  #k;
  constructor(t, e) {
    (super(), (this.#u = t), (this.#k = e));
  }
  write(t) {
    (this.#m.push({ data: t.slice(), start: this.pos }),
      (this.pos += t.byteLength));
  }
  flush() {
    if (0 === this.#m.length) return;
    let t = [],
      e = [...this.#m].sort((t, e) => t.start - e.start);
    t.push({ start: e[0].start, size: e[0].data.byteLength });
    for (let i = 1; i < e.length; i++) {
      let s = t[t.length - 1],
        r = e[i];
      r.start <= s.start + s.size
        ? (s.size = Math.max(s.size, r.start + r.data.byteLength - s.start))
        : t.push({ start: r.start, size: r.data.byteLength });
    }
    for (let e of t) {
      e.data = new Uint8Array(e.size);
      for (let t of this.#m)
        e.start <= t.start &&
          t.start < e.start + e.size &&
          e.data.set(t.data, t.start - e.start);
      if (this.#k && e.start < this.#w)
        throw new Error("Internal error: Monotonicity violation.");
      (this.#u.onData(e.data, e.start),
        (this.#w = e.start + e.data.byteLength));
    }
    this.#m.length = 0;
  }
  finalize() {
    this.#u.onDone?.();
  }
}
class v extends C {
  #u;
  #g;
  #C = [];
  #w = 0;
  #k;
  constructor(t, e) {
    if (
      (super(),
      (this.#u = t),
      (this.#g = t.options?.chunkSize ?? 16777216),
      (this.#k = e),
      !Number.isInteger(this.#g) || this.#g < 1024)
    )
      throw new Error(
        "Invalid StreamTarget options: chunkSize must be an integer not smaller than 1024.",
      );
  }
  write(t) {
    (this.#y(t, this.pos), this.#T(), (this.pos += t.byteLength));
  }
  #y(t, e) {
    let i = this.#C.findIndex((t) => t.start <= e && e < t.start + this.#g);
    -1 === i && (i = this.#v(e));
    let s = this.#C[i],
      r = e - s.start,
      a = t.subarray(0, Math.min(this.#g - r, t.byteLength));
    s.data.set(a, r);
    let n = { start: r, end: r + a.byteLength };
    if (
      (this.#V(s, n),
      0 === s.written[0].start &&
        s.written[0].end === this.#g &&
        (s.shouldFlush = !0),
      this.#C.length > 2)
    ) {
      for (let t = 0; t < this.#C.length - 1; t++) this.#C[t].shouldFlush = !0;
      this.#T();
    }
    a.byteLength < t.byteLength &&
      this.#y(t.subarray(a.byteLength), e + a.byteLength);
  }
  #V(t, e) {
    let i = 0,
      s = t.written.length - 1,
      r = -1;
    for (; i <= s; ) {
      let a = Math.floor(i + (s - i + 1) / 2);
      t.written[a].start <= e.start ? ((i = a + 1), (r = a)) : (s = a - 1);
    }
    for (
      t.written.splice(r + 1, 0, e),
        (-1 === r || t.written[r].end < e.start) && r++;
      r < t.written.length - 1 && t.written[r].end >= t.written[r + 1].start;
    )
      ((t.written[r].end = Math.max(t.written[r].end, t.written[r + 1].end)),
        t.written.splice(r + 1, 1));
  }
  #v(t) {
    let e = {
      start: Math.floor(t / this.#g) * this.#g,
      data: new Uint8Array(this.#g),
      written: [],
      shouldFlush: !1,
    };
    return (
      this.#C.push(e),
      this.#C.sort((t, e) => t.start - e.start),
      this.#C.indexOf(e)
    );
  }
  #T(t = !1) {
    for (let e = 0; e < this.#C.length; e++) {
      let i = this.#C[e];
      if (i.shouldFlush || t) {
        for (let t of i.written) {
          if (this.#k && i.start + t.start < this.#w)
            throw new Error("Internal error: Monotonicity violation.");
          (this.#u.onData(i.data.subarray(t.start, t.end), i.start + t.start),
            (this.#w = i.start + t.end));
        }
        this.#C.splice(e--, 1);
      }
    }
  }
  finalize() {
    (this.#T(!0), this.#u.onDone?.());
  }
}
class V extends v {
  constructor(t, e) {
    super(
      new k(
        (e, i) => t.stream.write({ type: "write", data: e, position: i }),
        void 0,
        { chunkSize: t.options?.chunkSize },
      ),
      e,
    );
  }
}
const b = 4096,
  M = "Expressive Animator",
  B = ["strict", "offset", "permissive"];
class S {
  #b;
  #M;
  #B;
  #S;
  #E;
  #z;
  #A;
  #D;
  #L;
  #U;
  #I;
  #P;
  #F;
  #x = 0;
  #N = [];
  #R = [];
  #H;
  #Q;
  #W = -1;
  #O = -1;
  #$;
  #q = !1;
  constructor(t) {
    (this.#G(t),
      (this.#b = { type: "webm", firstTimestampBehavior: "strict", ...t }),
      (this.target = t.target));
    let e = !!this.#b.streaming;
    if (t.target instanceof w) this.#M = new y(t.target);
    else if (t.target instanceof k)
      this.#M = t.target.options?.chunked
        ? new v(t.target, e)
        : new T(t.target, e);
    else {
      if (!(t.target instanceof g))
        throw new Error(`Invalid target: ${t.target}`);
      this.#M = new V(t.target, e);
    }
    this.#_();
  }
  #G(t) {
    if (t.type && "webm" !== t.type && "matroska" !== t.type)
      throw new Error(`Invalid type: ${t.type}`);
    if (t.firstTimestampBehavior && !B.includes(t.firstTimestampBehavior))
      throw new Error(
        `Invalid first timestamp behavior: ${t.firstTimestampBehavior}`,
      );
  }
  #_() {
    (this.#j(),
      this.#b.streaming || this.#J(),
      this.#K(),
      this.#X(),
      this.#Y(),
      this.#b.streaming || (this.#Z(), this.#tt()),
      this.#et(),
      this.#it());
  }
  #j() {
    let t = {
      id: p.EBML,
      data: [
        { id: p.EBMLVersion, data: 1 },
        { id: p.EBMLReadVersion, data: 1 },
        { id: p.EBMLMaxIDLength, data: 4 },
        { id: p.EBMLMaxSizeLength, data: 8 },
        { id: p.DocType, data: this.#b.type ?? "webm" },
        { id: p.DocTypeVersion, data: 2 },
        { id: p.DocTypeReadVersion, data: 2 },
      ],
    };
    this.#M.writeEBML(t);
  }
  #X() {
    ((this.#L = { id: p.Void, size: 4, data: new Uint8Array(b) }),
      (this.#U = { id: p.Void, size: 4, data: new Uint8Array(b) }));
  }
  #Y() {
    this.#D = {
      id: p.Colour,
      data: [
        { id: p.MatrixCoefficients, data: 2 },
        { id: p.TransferCharacteristics, data: 2 },
        { id: p.Primaries, data: 2 },
        { id: p.Range, data: 0 },
      ],
    };
  }
  #J() {
    const t = new Uint8Array([28, 83, 187, 107]),
      e = new Uint8Array([21, 73, 169, 102]),
      i = new Uint8Array([22, 84, 174, 107]);
    let s = {
      id: p.SeekHead,
      data: [
        {
          id: p.Seek,
          data: [
            { id: p.SeekID, data: t },
            { id: p.SeekPosition, size: 5, data: 0 },
          ],
        },
        {
          id: p.Seek,
          data: [
            { id: p.SeekID, data: e },
            { id: p.SeekPosition, size: 5, data: 0 },
          ],
        },
        {
          id: p.Seek,
          data: [
            { id: p.SeekID, data: i },
            { id: p.SeekPosition, size: 5, data: 0 },
          ],
        },
      ],
    };
    this.#E = s;
  }
  #K() {
    let t = { id: p.Duration, data: new c(0) };
    this.#A = t;
    let e = {
      id: p.Info,
      data: [
        { id: p.TimestampScale, data: 1e6 },
        { id: p.MuxingApp, data: M },
        { id: p.WritingApp, data: M },
        this.#b.streaming ? null : t,
      ],
    };
    this.#S = e;
  }
  #Z() {
    let t = { id: p.Tracks, data: [] };
    ((this.#z = t),
      this.#b.video &&
        t.data.push({
          id: p.TrackEntry,
          data: [
            { id: p.TrackNumber, data: 1 },
            { id: p.TrackUID, data: 1 },
            { id: p.TrackType, data: 1 },
            { id: p.CodecID, data: this.#b.video.codec },
            this.#L,
            this.#b.video.frameRate
              ? { id: p.DefaultDuration, data: 1e9 / this.#b.video.frameRate }
              : null,
            {
              id: p.Video,
              data: [
                { id: p.PixelWidth, data: this.#b.video.width },
                { id: p.PixelHeight, data: this.#b.video.height },
                this.#b.video.alpha ? { id: p.AlphaMode, data: 1 } : null,
                this.#D,
              ],
            },
          ],
        }),
      this.#b.audio &&
        ((this.#U = this.#b.streaming
          ? this.#U || null
          : { id: p.Void, size: 4, data: new Uint8Array(b) }),
        t.data.push({
          id: p.TrackEntry,
          data: [
            { id: p.TrackNumber, data: 2 },
            { id: p.TrackUID, data: 2 },
            { id: p.TrackType, data: 2 },
            { id: p.CodecID, data: this.#b.audio.codec },
            this.#U,
            {
              id: p.Audio,
              data: [
                {
                  id: p.SamplingFrequency,
                  data: new u(this.#b.audio.sampleRate),
                },
                { id: p.Channels, data: this.#b.audio.numberOfChannels },
                this.#b.audio.bitDepth
                  ? { id: p.BitDepth, data: this.#b.audio.bitDepth }
                  : null,
              ],
            },
          ],
        })));
  }
  #tt() {
    let t = {
      id: p.Segment,
      size: this.#b.streaming ? -1 : 6,
      data: [this.#b.streaming ? null : this.#E, this.#S, this.#z],
    };
    ((this.#B = t), this.#M.writeEBML(t));
  }
  #et() {
    this.#I = { id: p.Cues, data: [] };
  }
  #it() {
    this.#M instanceof T && this.#M.flush();
  }
  get #st() {
    return this.#M.dataOffsets.get(this.#B);
  }
  addAlphaChunk(t, e, i) {
    let s = new Uint8Array(t.byteLength);
    t.copyTo(s);
    const r = new Uint8Array(e.byteLength);
    (e.copyTo(r), this.addAlphaChunkRaw(s, r, t.type, t.timestamp, i));
  }
  addAlphaChunkRaw(t, e, i, s, r) {
    if ((this.#rt(), !this.#b.video))
      throw new Error("No video track declared.");
    (void 0 === this.#H && (this.#H = s), r && this.#at(r));
    let a = this.#nt(t, i, s, 1, e);
    for (
      "V_VP9" === this.#b.video.codec && this.#ot(a), this.#W = a.timestamp;
      this.#R.length > 0 && this.#R[0].timestamp <= a.timestamp;
    ) {
      let t = this.#R.shift();
      this.#ht(t);
    }
    (!this.#b.audio || a.timestamp <= this.#O ? this.#ht(a) : this.#N.push(a),
      this.#it());
  }
  addVideoChunk(t, e, i) {
    let s = new Uint8Array(t.byteLength);
    (t.copyTo(s), this.addVideoChunkRaw(s, t.type, i ?? t.timestamp, e));
  }
  addVideoChunkRaw(t, e, i, s) {
    if ((this.#rt(), !this.#b.video))
      throw new Error("No video track declared.");
    (void 0 === this.#H && (this.#H = i), s && this.#at(s));
    let r = this.#nt(t, e, i, 1);
    for (
      "V_VP9" === this.#b.video.codec && this.#ot(r), this.#W = r.timestamp;
      this.#R.length > 0 && this.#R[0].timestamp <= r.timestamp;
    ) {
      let t = this.#R.shift();
      this.#ht(t);
    }
    (!this.#b.audio || r.timestamp <= this.#O ? this.#ht(r) : this.#N.push(r),
      this.#it());
  }
  #at(t) {
    if (t.decoderConfig) {
      if (t.decoderConfig.colorSpace) {
        let e = t.decoderConfig.colorSpace;
        if (
          ((this.#$ = e),
          (this.#D.data = [
            {
              id: p.MatrixCoefficients,
              data: { rgb: 1, bt709: 1, bt470bg: 5, smpte170m: 6 }[e.matrix],
            },
            {
              id: p.TransferCharacteristics,
              data: { bt709: 1, smpte170m: 6, "iec61966-2-1": 13 }[e.transfer],
            },
            {
              id: p.Primaries,
              data: { bt709: 1, bt470bg: 5, smpte170m: 6 }[e.primaries],
            },
            { id: p.Range, data: [1, 2][Number(e.fullRange)] },
          ]),
          !this.#b.streaming)
        ) {
          let t = this.#M.pos;
          (this.#M.seek(this.#M.offsets.get(this.#D)),
            this.#M.writeEBML(this.#D),
            this.#M.seek(t));
        }
      }
      t.decoderConfig.description &&
        (this.#b.streaming
          ? (this.#L = this.#dt(t.decoderConfig.description))
          : this.#lt(this.#L, t.decoderConfig.description));
    }
  }
  #ot(t) {
    if ("key" !== t.type) return;
    if (!this.#$) return;
    let e = 0;
    if (2 !== m(t.data, 0, 2)) return;
    e += 2;
    let i = (m(t.data, e + 1, e + 2) << 1) + m(t.data, e + 0, e + 1);
    ((e += 2), 3 === i && e++);
    let s = m(t.data, e + 0, e + 1);
    if ((e++, s)) return;
    let r = m(t.data, e + 0, e + 1);
    if ((e++, 0 !== r)) return;
    e += 2;
    let a = m(t.data, e + 0, e + 24);
    if (((e += 24), 4817730 !== a)) return;
    i >= 2 && e++;
    let n = { rgb: 7, bt709: 2, bt470bg: 1, smpte170m: 3 }[this.#$.matrix];
    ((t, e, i, s) => {
      for (let r = e; r < i; r++) {
        let e = Math.floor(r / 8),
          a = t[e],
          n = 7 - (7 & r);
        ((a &= ~(1 << n)),
          (a |= ((s & (1 << (i - r - 1))) >> (i - r - 1)) << n),
          (t[e] = a));
      }
    })(t.data, e + 0, e + 3, n);
  }
  addAudioChunk(t, e, i) {
    let s = new Uint8Array(t.byteLength);
    (t.copyTo(s), this.addAudioChunkRaw(s, t.type, i ?? t.timestamp, e));
  }
  addAudioChunkRaw(t, e, i, s) {
    if ((this.#rt(), !this.#b.audio))
      throw new Error("No audio track declared.");
    (void 0 === this.#Q && (this.#Q = i),
      s?.decoderConfig &&
        (this.#b.streaming
          ? (this.#U = this.#dt(s.decoderConfig.description))
          : this.#lt(this.#U, s.decoderConfig.description)));
    let r = this.#nt(t, e, i, 2);
    for (
      this.#O = r.timestamp;
      this.#N.length > 0 && this.#N[0].timestamp <= r.timestamp;
    ) {
      let t = this.#N.shift();
      this.#ht(t);
    }
    (!this.#b.video || r.timestamp <= this.#W ? this.#ht(r) : this.#R.push(r),
      this.#it());
  }
  #nt(t, e, i, s, r) {
    return {
      data: t,
      type: e,
      timestamp: this.#ut(i, s),
      trackNumber: s,
      alpha: r,
    };
  }
  #ut(t, e) {
    let i = 1 === e ? this.#H : this.#Q,
      s = 1 === e ? this.#W : this.#O;
    if ("strict" === this.#b.firstTimestampBehavior && -1 === s && 0 !== t)
      throw new Error(
        `The first chunk for your media track must have a timestamp of 0 (received ${t}). Non-zero first timestamps are often caused by directly piping frames or audio data from a MediaStreamTrack into the encoder. Their timestamps are typically relative to the age of the document, which is probably what you want.\n\nIf you want to offset all timestamps of a track such that the first one is zero, set firstTimestampBehavior: 'offset' in the options.\nIf you want to allow non-zero first timestamps, set firstTimestampBehavior: 'permissive'.\n`,
      );
    if (("offset" === this.#b.firstTimestampBehavior && (t -= i), t < s))
      throw new Error(
        `Timestamps must be monotonically increasing (went from ${s} to ${t}).`,
      );
    return t;
  }
  #ht(t) {
    this.#b.streaming && !this.#z && (this.#Z(), this.#tt());
    let e = Math.floor(t.timestamp / 1e3);
    if ("key" !== t.type && e - this.#F >= 32768)
      throw new Error(
        "Current Matroska cluster exceeded its maximum allowed length of 32768 milliseconds. In order to produce a correct WebM file, you must pass in a video key frame at least every 32768 milliseconds.",
      );
    let i =
      (1 === t.trackNumber || !this.#b.video) &&
      "key" === t.type &&
      e - this.#F >= 1e3;
    if (((this.#P && !i) || this.#ct(e), t.alpha)) {
      const i = new Uint8Array(4),
        s = new DataView(i.buffer);
      (s.setUint8(0, 128 | t.trackNumber),
        s.setUint16(1, e - this.#F, !1),
        s.setUint8(3, 0));
      const r = {
        id: p.BlockGroup,
        data: [
          { id: p.Block, data: [i, t.data] },
          {
            id: p.BlockAdditions,
            data: [
              {
                id: p.BlockMore,
                data: [
                  { id: p.BlockAddID, data: 1 },
                  { id: p.BlockAdditional, data: t.alpha },
                ],
              },
            ],
          },
        ],
      };
      this.#M.writeEBML(r);
    } else {
      let i = new Uint8Array(4),
        s = new DataView(i.buffer);
      (s.setUint8(0, 128 | t.trackNumber),
        s.setUint16(1, e - this.#F, !1),
        s.setUint8(3, Number("key" === t.type) << 7));
      let r = { id: p.SimpleBlock, data: [i, t.data] };
      this.#M.writeEBML(r);
    }
    this.#x = Math.max(this.#x, e);
  }
  #dt(t) {
    return { id: p.CodecPrivate, size: 4, data: new Uint8Array(t) };
  }
  #lt(t, e) {
    let i = this.#M.pos;
    (this.#M.seek(this.#M.offsets.get(t)),
      (t = [
        this.#dt(e),
        { id: p.Void, size: 4, data: new Uint8Array(4090 - e.byteLength) },
      ]),
      this.#M.writeEBML(t),
      this.#M.seek(i));
  }
  #ct(t) {
    (this.#P && !this.#b.streaming && this.#pt(),
      (this.#P = {
        id: p.Cluster,
        size: this.#b.streaming ? -1 : 5,
        data: [{ id: p.Timestamp, data: t }],
      }),
      this.#M.writeEBML(this.#P),
      (this.#F = t));
    let e = this.#M.offsets.get(this.#P) - this.#st;
    this.#I.data.push({
      id: p.CuePoint,
      data: [
        { id: p.CueTime, data: t },
        this.#b.video
          ? {
              id: p.CueTrackPositions,
              data: [
                { id: p.CueTrack, data: 1 },
                { id: p.CueClusterPosition, data: e },
              ],
            }
          : null,
        this.#b.audio
          ? {
              id: p.CueTrackPositions,
              data: [
                { id: p.CueTrack, data: 2 },
                { id: p.CueClusterPosition, data: e },
              ],
            }
          : null,
      ],
    });
  }
  #pt() {
    let t = this.#M.pos - this.#M.dataOffsets.get(this.#P),
      e = this.#M.pos;
    (this.#M.seek(this.#M.offsets.get(this.#P) + 4),
      this.#M.writeEBMLVarInt(t, 5),
      this.#M.seek(e));
  }
  finalize() {
    for (; this.#N.length > 0; ) this.#ht(this.#N.shift());
    for (; this.#R.length > 0; ) this.#ht(this.#R.shift());
    if (
      (this.#b.streaming || this.#pt(),
      this.#M.writeEBML(this.#I),
      !this.#b.streaming)
    ) {
      let t = this.#M.pos,
        e = this.#M.pos - this.#st;
      (this.#M.seek(this.#M.offsets.get(this.#B) + 4),
        this.#M.writeEBMLVarInt(e, 6),
        (this.#A.data = new c(this.#x)),
        this.#M.seek(this.#M.offsets.get(this.#A)),
        this.#M.writeEBML(this.#A),
        (this.#E.data[0].data[1].data =
          this.#M.offsets.get(this.#I) - this.#st),
        (this.#E.data[1].data[1].data =
          this.#M.offsets.get(this.#S) - this.#st),
        (this.#E.data[2].data[1].data =
          this.#M.offsets.get(this.#z) - this.#st),
        this.#M.seek(this.#M.offsets.get(this.#E)),
        this.#M.writeEBML(this.#E),
        this.#M.seek(t));
    }
    (this.#it(), this.#M.finalize(), (this.#q = !0));
  }
  #rt() {
    if (this.#q)
      throw new Error(
        "Cannot add new video or audio chunks after the file has been finalized.",
      );
  }
}
const E = new Map([
    [122880, [20, 21]],
    [245760, [21, 30]],
    [552960, [30, 31]],
    [983040, [31, 40]],
    [2228224, [40, 41]],
    [8912896, [50, 51]],
    [35651584, [60, 61]],
  ]),
  z = new Map([
    [122880, [1.8, 3.6]],
    [245760, [3.6, 7.2]],
    [552960, [7.2, 12]],
    [983040, [12, 18]],
    [2228224, [18, 30]],
    [8912896, [60, 120]],
    [35651584, [180, 240]],
  ]);
function A(t) {
  return "vp9" === t.codec
    ? `vp09.00.${d(t, E).toString().padStart(2, "0")}.08`
    : t.codec;
}
function D(t) {
  return (function (t, e) {
    return Math.round(1e6 * (t.quality || 1) * d(t, e));
  })(t, z);
}
var L;
((L = async function (t, e) {
  const i = {
    codec: A(t),
    bitrate: D(t),
    framerate: l(t),
    width: t.size.width,
    height: t.size.height,
    latencyMode: "quality",
    bitrateMode: "constant",
    hardwareAcceleration: "no-preference",
  };
  if (
    !(await (async function (t) {
      return (await VideoEncoder.isConfigSupported(t))?.supported;
    })(i))
  )
    throw new Error(`Cannot create video encoder ${i.codec}`);
  const s = await e.createWritable();
  try {
    await (async function (t, e, i) {
      const s = t.alpha,
        d = new S({
          target: new k(
            (t, e) => {
              i.write({ data: t, position: e, type: "write" });
            },
            void 0,
            { chunked: !1 },
          ),
          video: {
            width: t.size.width,
            height: t.size.height,
            codec: "vp9" === t.codec ? "V_VP9" : "V_VP8",
            frameRate: l(t),
            alpha: s,
          },
          firstTimestampBehavior: "offset",
        }),
        u = [],
        c = s ? [] : null;
      function p() {
        for (; Math.min(u.length, c.length) > 0; ) {
          const t = c.shift(),
            e = u.shift();
          d.addAlphaChunk(e[0], t, e[1]);
        }
      }
      const f = new VideoEncoder({
          output: async (t, e) => {
            s ? (u.push([t, e]), p()) : d.addVideoChunk(t, e);
          },
          error: n,
        }),
        m = s
          ? new VideoEncoder({
              output: async (t) => {
                (c.push(t), p());
              },
              error: n,
            })
          : null;
      return (
        f.configure(e),
        m?.configure(e),
        (async function (t, e, i, s) {
          const n = new o(null, h),
            d = { keyFrame: !1 };
          for (const e of (function* (t) {
            const e = t.repeat || 1,
              i = t.startTime || 0,
              s = t.speed || 1,
              n = t.fps * (s < 1 ? 1 / s : 1),
              o = 1e3 / n,
              h = Math.ceil(t.duration / o);
            let d = 0,
              l = !t.reverse;
            const u = e * h,
              c = t.keyframe || 0,
              p = {
                time: 0,
                frame: 0,
                relativeFrame: 0,
                timestamp: 0,
                keyframe: !1,
                progress: 0,
                fps: n,
                totalRepeats: e,
                totalFrames: u,
              };
            for (let n = 0; n < e; n++) {
              for (let t = d; t < h; t++) {
                if (r || a) return p;
                ((p.relativeFrame = l ? t : h - 1 - t),
                  (p.time = i + Math.round(p.relativeFrame * o)),
                  (p.frame = n * h + t),
                  (p.timestamp = 1e3 * Math.round((p.frame * o) / s)),
                  (p.keyframe = c
                    ? !(p.frame % c)
                    : t === d || !(p.frame % 120)),
                  (p.progress = p.frame / u),
                  yield p);
              }
              t.alternate && ((l = !l), (d = 1));
            }
            return p;
          })(t)) {
            ((l = e.progress), self.postMessage([2, [l, void 0]]));
            const r = await n.fetch(e.time),
              a = new VideoFrame(r, { timestamp: e.timestamp });
            if (((d.keyFrame = e.keyframe), i.encode(a, d), s)) {
              const i = new ArrayBuffer(a.allocationSize());
              await a.copyTo(i);
              const r = new Uint8ClampedArray(i);
              for (let t = 0; t < r.byteLength; t += 4)
                ((r[t] = r[t + 1] = r[t + 2] = r[t + 3]), (r[t + 3] = 255));
              const n = new VideoFrame(r.buffer, {
                timestamp: e.timestamp,
                codedWidth: t.size.width,
                codedHeight: t.size.height,
                format: "RGBA",
              });
              (s.encode(n, d), n.close());
            }
            a.close();
          }
          var l;
          (n.dispose(),
            r
              ? (i.reset(), s?.reset())
              : a || (await i.flush(), await s?.flush(), e && (await e())),
            "closed" !== i.state && i.close(),
            s && "closed" !== s.state && s.close());
        })(
          t,
          () => {
            if (s) p();
            else if (u.length) for (const [t, e] of u) d.addVideoChunk(t, e);
            d.finalize();
          },
          f,
          m,
        )
      );
    })(t, i, s);
  } finally {
    await s.close();
  }
}),
  t ||
    ((r = a = !1),
    (s = null),
    (i = null),
    (self.onmessage = async function (i) {
      const [o, h] = i.data;
      switch (o) {
        case 0:
          if (t)
            try {
              await t(h[0], h[1]);
            } catch (i) {
              r || n(i);
            } finally {
              ((t = null),
                (function () {
                  const t = { type: r ? "aborted" : a ? "error" : "ok" };
                  ("error" === t.type && (t.message = s),
                    self.postMessage([3, t]));
                })());
            }
          return;
        case 1:
          return (e?.(h), void (e = null));
        case 2:
          return void (r || (r = !0));
      }
    }),
    (t = L),
    self.postMessage([0])));
