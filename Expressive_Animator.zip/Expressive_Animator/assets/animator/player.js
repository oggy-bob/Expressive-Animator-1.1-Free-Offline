!(function () {
  "use strict";
  function t(t, n, e, i, r, s, u) {
    let o = t;
    for (let e = 0; e < 8; e++) {
      const e = n * o * o * o + i * o * o + s * o - t;
      if (Math.abs(e) <= 5e-5) break;
      const r = 3 * n * o * o + 2 * i * o + s;
      o -= (2 * e * r) / (2 * r * r - e * (6 * n * o + 2 * i));
    }
    return ((e * o + r) * o + u) * o;
  }
  const n = [
    null,
    (n) => t(n, -0.74, -2, 0.48, 3, 1.26, 0),
    (n) => t(n, -0.74, -2, 1.74, 3, 0, 0),
    (n) => t(n, 0.52, -2, -0.78, 3, 1.26, 0),
    (t) => (t > 0 ? 1 : 0),
    (t) => (t < 1 ? 0 : 1),
    (t) => (t < 0.5 ? 0 : 1),
  ];
  let e;
  function i(t) {
    if (!t) return null;
    if ("number" == typeof t) return n[t];
    if (!e) return null;
    let i = t.shift();
    return e[i] ? e[i](...t) : null;
  }
  function r(t) {
    return (...n) => {
      return (e = t(...n)) ? (t) => 1 - e(1 - t) : null;
      var e;
    };
  }
  function s(t, n) {
    const e = (1 + (n += 1.0001)) / (1 - n),
      i = 1 - ((1 + n) * n ** t) / 2;
    return (r) => {
      const s = Math.floor(Math.log(1 - r * i) / Math.log(n));
      return (
        (1 - ((2 * (r * i - 1)) / ((1 - n) * n ** s) + e) ** 2) / n ** (t - s)
      );
    };
  }
  function u(t = 1.7) {
    return (n) => n * n * (n + t * (n - 1));
  }
  function o(t, n) {
    if (((t = 2 * Math.PI * (t + 0.25)), 0 == n))
      return (n) => n * Math.sin(n * t);
    const e = Math.exp(n) - 1;
    return (i) => ((Math.exp(n * i) - 1) * Math.sin(i * t)) / e;
  }
  function l(...t) {
    if (0 === t.length) return null;
    const n = t.length;
    return (e) => {
      if (e < 0) return 0;
      let i = 0,
        r = 0;
      for (let s = 0; s < n; s += 2) {
        const n = t[s],
          u = t[s + 1];
        if (e === n) return u;
        if (e < n) return r + ((u - r) * (e - i)) / (n - i);
        ((i = n), (r = u));
      }
      return e >= 1 ? 1 : r + ((1 - r) * (e - i)) / (1 - i);
    };
  }
  function h(n, e, i, r) {
    if (c(n, e) && c(i, r)) return null;
    const s = 1 + 3 * (n - i),
      u = 1 + 3 * (e - r),
      o = 3 * (i - 2 * n),
      l = 3 * (r - 2 * e),
      h = 3 * n,
      f = 3 * e;
    return c(o, 0) && c(h, 0)
      ? (t) => ((t = Math.pow(t / s, 1 / 3)), ((u * t + l) * t + f) * t)
      : (n) => t(n, s, u, o, l, h, f);
  }
  function c(t, n) {
    return Math.abs(t - n) <= 1e-6;
  }
  function f(t, n) {
    return t[0] - n[0];
  }
  function a(t, n) {
    return !n || (t >= n[0] && t <= n[1]);
  }
  function p(t, n, e) {
    return !t || (t[0] <= 0 && t[1] >= n)
      ? null
      : (1 !== e && ((t[0] /= e), (t[1] /= e)), t);
  }
  function d(t) {
    return t;
  }
  class g {
    constructor(t, n, e, i, r) {
      ((this.d = t),
        (this.m = e),
        (this.vis = i),
        i && null != r
          ? (this.h = r)
          : 1 === n.length && ((this.value = n[0][1]), (n = null)),
        (this.k = n));
    }
    get isAnimated() {
      return null != (this.vis || this.k);
    }
    update(t) {
      if (!this.k) return !1;
      const n =
        null == this.h || a(t, this.vis)
          ? (function (t, n, e) {
              if (t <= n[0][0]) return n[0][1];
              const i = n.length - 1;
              if (t > n[i][0]) return n[i][1];
              let r = 1;
              for (; r < i && !(t <= n[r][0]); r++);
              const s = n[r - 1],
                u = n[r];
              return s[0] === t
                ? s[1]
                : u[0] === t
                  ? u[1]
                  : ((t = (t - s[0]) / (u[0] - s[0])),
                    e(s[1], u[1], s[2] ? s[2](t) : t));
            })(t, this.k, this.d[0])
          : this.h;
      return !(
        (void 0 !== this.value && this.d[2](n, this.value)) ||
        ((this.value = n), (this.s = null), 0)
      );
    }
    toString() {
      return (this.s ??= this.d[1](this.value, this.m));
    }
  }
  class M {
    constructor(t, n, e, i) {
      ((this.d = t),
        (this.m = e),
        (this.c = new Array(n.length)),
        (this.vis = i));
      const r = [],
        s = this.d[3];
      for (let t = 0; t < n.length; t++)
        n[t].isAnimated
          ? r.push([t, n[t]])
          : (this.c[t] = s ? n[t].toString() : n[t].value);
      0 === r.length
        ? ((this.a = null), (this.value = this.d[0](this.c, this.m)))
        : (this.a = r);
    }
    get isAnimated() {
      return null != (this.vis || this.a);
    }
    update(t) {
      if (null == this.a) return !1;
      let n = !1;
      const e = this.c;
      if (this.d[3])
        for (const [i, r] of this.a)
          r.update(t) && ((e[i] = r.toString()), (n = !0));
      else
        for (const [i, r] of this.a)
          r.update(t) && ((e[i] = r.value), (n = !0));
      if (!n) return !1;
      const i = this.d[0](e, this.m);
      return !(
        (void 0 !== this.value && this.d[2](i, this.value)) ||
        ((this.value = i), (this.s = null), 0)
      );
    }
    toString() {
      return (this.s ??= this.d[1](this.value, this.m));
    }
  }
  class $ {
    constructor(t, n) {
      ((this.vis = n), (this.p = t));
      const e = (this.l = []);
      let i = !1;
      for (const n of t)
        if (n.isAnimated) i = !0;
        else {
          const t = n.toString();
          t && e.push(t);
        }
      (i
        ? ((this.a = !0), (this.i = null))
        : ((this.a = !1),
          e.length ? ((this.i = e.join(" ")), e.splice(0)) : (this.i = null),
          (this.l = null)),
        (this.isAnimated = i || null != n));
    }
    update(t) {
      let n = null;
      if (a(t, this.vis))
        if (this.a) {
          const e = this.l;
          for (const n of this.p) {
            if (!a(t, n.vis)) continue;
            n.update(t);
            const i = n.toString();
            i && e.push(i);
          }
          e.length && ((n = e.join(" ")), e.splice(0));
        } else n = this.i;
      return n !== this.value && ((this.value = n), !0);
    }
    toString() {
      return this.value || "none";
    }
  }
  const m = [
      (t) =>
        1 === t
          ? null
          : [t, 0, 0, 0, 0, 0, t, 0, 0, 0, 0, 0, t, 0, 0, 0, 0, 0, 1, 0],
      (t) => {
        if (1 === t) return null;
        const n = (1 - t) / 2;
        return [t, 0, 0, 0, n, 0, t, 0, 0, n, 0, 0, t, 0, n, 0, 0, 0, 1, 0];
      },
      (t) =>
        1 === t
          ? null
          : [
              0.213 + 0.787 * t,
              0.715 - 0.715 * t,
              0.072 - 0.072 * t,
              0,
              0,
              0.213 - 0.213 * t,
              0.715 + 0.285 * t,
              0.072 - 0.072 * t,
              0,
              0,
              0.213 - 0.213 * t,
              0.715 - 0.715 * t,
              0.072 + 0.928 * t,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
            ],
      (t) => {
        if (t % 360 == 0) return null;
        t *= Math.PI / 180;
        const n = Math.cos(t),
          e = Math.sin(t);
        return [
          0.787 * n + 0.213 * (1 - e),
          0.715 * (1 - n - e),
          0.072 * (1 - n) + 0.928 * e,
          0,
          0,
          0.213 * (1 - n) + 0.143 * e,
          0.715 + 0.285 * n + 0.14 * e,
          0.072 * (1 - n) - 0.283 * e,
          0,
          0,
          0.213 * (1 - n) - 0.787 * e,
          0.715 * (1 - n + e),
          0.928 * n + 0.072 * (1 + e),
          0,
          0,
          0,
          0,
          0,
          1,
          0,
        ];
      },
      (t) => {
        if (!t) return null;
        const n = t;
        return [
          (t = -2 * t + 1),
          0,
          0,
          0,
          n,
          0,
          t,
          0,
          0,
          n,
          0,
          0,
          t,
          0,
          n,
          0,
          0,
          0,
          1,
          0,
        ];
      },
      (t) =>
        t
          ? [
              0.2126 + 0.7874 * (t = 1 - t),
              0.7152 - 0.7152 * t,
              0.0722 - 0.0722 * t,
              0,
              0,
              0.2126 - 0.2126 * t,
              0.7152 + 0.2848 * t,
              0.0722 - 0.0722 * t,
              0,
              0,
              0.2126 - 0.2126 * t,
              0.7152 - 0.7152 * t,
              0.0722 + 0.9278 * t,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
            ]
          : null,
      (t) =>
        t
          ? [
              0.393 + 0.607 * (t = 1 - t),
              0.769 - 0.769 * t,
              0.189 - 0.189 * t,
              0,
              0,
              0.349 - 0.349 * t,
              0.686 + 0.314 * t,
              0.168 - 0.168 * t,
              0,
              0,
              0.272 - 0.272 * t,
              0.534 - 0.534 * t,
              0.131 + 0.869 * t,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
            ]
          : null,
    ],
    v = new Array(20).fill(0);
  function S(t, n, e) {
    (t === e && (t = t.slice()), n === e && (n = n.slice()));
    let i = 0;
    for (let r = 0; r < 20; r += 5) {
      for (let s = 0; s < 4; s++)
        e[i++] =
          t[r + 0] * n[s + 0] +
          t[r + 1] * n[s + 5] +
          t[r + 2] * n[s + 10] +
          t[r + 3] * n[s + 15];
      e[i++] =
        t[r + 0] * n[4] +
        t[r + 1] * n[9] +
        t[r + 2] * n[14] +
        t[r + 3] * n[19] +
        t[r + 4];
    }
  }
  v[0] = v[6] = v[12] = v[18] = 1;
  const y = [1, -1, 0, 0, -1, 1, 0, 0],
    w = [0, 1, 1, 1, 1, 0, 0, 0],
    b = [0, 1, 1, 2, 2, 3, 3, 0],
    _ = Math.PI / 180,
    A = Math.PI / 2,
    x = 0.47829;
  function I(t, n, e, i, r, s, u, o, l) {
    const h = new DOMMatrix().translateSelf(t, n).rotateSelf(e);
    return (
      (s %= 360) &&
        ((u %= 360)
          ? h.rotateSelf(-u).skewXSelf(-s).rotateSelf(u)
          : h.skewXSelf(-s)),
      h.scaleSelf(i, r).translateSelf(-o, -l)
    );
  }
  function k(t, n = 0, e = 1) {
    return t <= n ? n : t >= e ? e : t;
  }
  function P(t, n, e) {
    return t + (n - t) * e;
  }
  function j(t, n, e) {
    return Math.max(0, t + (n - t) * e);
  }
  function E(t, n, e) {
    return k(t + (n - t) * e);
  }
  function L(t, n, e) {
    return e < 0.5 ? t : n;
  }
  function Z(t, n, e) {
    if (t.length !== n.length) return L(t, n, e);
    const i = [];
    for (let r = 0; r < t.length; r++) i[r] = P(t[r], n[r], e);
    return i;
  }
  function C(t, n, e) {
    if (t.length !== n.length) return L(t, n, e);
    const i = [];
    for (let r = 0; r < t.length; r++) i[r] = Math.max(0, P(t[r], n[r], e));
    return i;
  }
  function G(t, n, e) {
    return Math.round(k(t + (n - t) * e, 0, 255));
  }
  function O(t) {
    return Number.isInteger(t)
      ? t.toString()
      : (Math.round(1e9 * t) / 1e9).toString();
  }
  function V(t) {
    return t.map(O).join(" ");
  }
  const F = /\*/g;
  let N, q;
  function B() {
    return O(N[q++]);
  }
  function D() {
    return N[q++];
  }
  function T(t, n) {
    return ((q = 0), (N = t), n.replace(F, B));
  }
  function X(t, n) {
    return n.replace("*", O(t));
  }
  function z(t) {
    return `matrix(${t.a} ${t.b} ${t.c} ${t.d} ${t.e} ${t.f})`;
  }
  function J(t, n) {
    return t === n;
  }
  function U(t, n) {
    if (t === n) return !0;
    if (t.length !== n.length) return !1;
    for (let e = 0; e < t.length; e++) if (t[e] !== n[e]) return !1;
    return !0;
  }
  function H(t, n) {
    return (
      t.a === n.a &&
      t.b === n.b &&
      t.c === n.c &&
      t.d === n.d &&
      t.e === n.e &&
      t.f === n.f
    );
  }
  const K = new Map([]);
  function Q(t, n, e, i) {
    K.set(t, [0, n, e, i]);
  }
  function R(t, n, e) {
    (n[3] || (n[3] = !1), K.set(t, [1, n, e]));
  }
  function W(t, n) {
    return n && n.length ? n.map((n) => Y(t, n[0], n[1], n[2], n[3])) : null;
  }
  function Y(t, n, e, r, s) {
    const u = K.get(n);
    if (!u) throw "Unknown property";
    if (2 === u[0]) return new $(W(t, e), p(r, t.d, t.s));
    if (((r = u[2] ? u[2](r, t) : r), (s = p(s, t.d, t.s)), 0 === u[0])) {
      const n = (function (t, n, e) {
        if (!t) return null;
        for (const r of t)
          ((r[0] = r[0] / n.s), e && (r[1] = e(r[1], n)), (r[2] = i(r[2])));
        return t.sort(f);
      })(e, t, u[3]);
      return new g(
        u[1],
        n,
        r,
        s,
        (function (t) {
          return t && 3 === t.length ? t.pop() : null;
        })(s),
      );
    }
    return new M(u[1], W(t, e), r, s);
  }
  function tt(t, n) {
    return "string" == typeof t ? t : n.t[t];
  }
  (Q(0, [P, O, J]),
    Q(1, [j, O, J]),
    Q(2, [E, O, J]),
    Q(3, [P, X, J], tt),
    Q(4, [j, X, J], tt),
    Q(5, [E, X, J], tt),
    Q(6, [Z, V, U]),
    Q(7, [C, V, U]),
    Q(8, [Z, T, U], tt),
    Q(9, [C, T, U], tt),
    Q(12, [L, d, J], null, function (t, n) {
      return "string" == typeof t ? t : n.t[t];
    }),
    Q(10, [
      function (t, n, e) {
        return e <= 0
          ? t
          : e >= 1
            ? n
            : [
                G(t[0], n[0], e),
                G(t[1], n[1], e),
                G(t[2], n[2], e),
                E(t[3] ?? 1, n[3] ?? 1, e),
              ];
      },
      function (t) {
        return null == t[3] || 1 === t[3]
          ? `rgb(${t[0]} ${t[1]} ${t[2]})`
          : `rgb(${t[0]} ${t[1]} ${t[2]} / ${t[3]})`;
      },
      function (t, n) {
        return (
          t[0] === n[0] &&
          t[1] === n[1] &&
          t[2] === n[2] &&
          (t[3] ?? 1) == (n[3] ?? 1)
        );
      },
    ]),
    Q(
      11,
      [
        L,
        function (t, n) {
          return t ? `url('#${n}:${t}')` : "none";
        },
        J,
      ],
      function (t, n) {
        return n.p;
      },
    ),
    R(
      13,
      [
        function ([t, n, e, i, r, s], u) {
          return (function (t, n, e, i, r, s, u) {
            if (2 === t.length)
              return I(t[0], t[1], e, i[0], i[1], r, s, u[0], u[1]);
            const [o, l] = (function (t, n) {
              t *= n[1];
              let e = 0;
              const i = n[0].getPointAtLength(t);
              if (n[2]) {
                let r;
                (t + 0.01 > n[1]
                  ? ((r = n[0].getPointAtLength(t - 0.01)), (e += 180))
                  : (r = n[0].getPointAtLength(t + 0.01)),
                  (e += (180 * Math.atan2(r.y - i.y, r.x - i.x)) / Math.PI),
                  n[2] < 0 && (e += 180));
              }
              return [i, e];
            })(n, t);
            return I(o.x, o.y, e + l, i[0], i[1], r, s, u[0], u[1]);
          })(u, t, n, e, i, r, s);
        },
        z,
        H,
      ],
      function (t) {
        return t
          ? "string" == typeof t[0]
            ? (function (t, n) {
                const e = document.createElementNS(
                  "http://www.w3.org/2000/svg",
                  "path",
                );
                return (e.setAttribute("d", t), [e, e.getTotalLength(), n]);
              })(t[0], t[1])
            : t
          : [0, 0];
      },
    ),
    R(14, [
      function ([t, n, e]) {
        return (function (t, n, e) {
          return new DOMMatrix()
            .translateSelf(t[0], t[1])
            .rotateSelf(n)
            .scaleSelf(1, e)
            .translateSelf(-t[0], -t[1]);
        })(t, n, e);
      },
      z,
      H,
    ]),
    K.set(15, [2]),
    R(
      16,
      [
        function (t, n) {
          return ((q = 0), (N = t), n.replace(F, D));
        },
        d,
        J,
        !0,
      ],
      tt,
    ),
    R(17, [
      function ([t, n, e]) {
        return (function (t, n, e) {
          if (!(e[0] || e[1] || e[2] || e[3])) return `M0 0h${t}v${n}h-${t}z`;
          const i =
              t && n
                ? Math.min(
                    t / (e[0] + e[1]),
                    n / (e[1] + e[2]),
                    t / (e[2] + e[3]),
                    n / (e[3] + e[0]),
                    1,
                  )
                : 0,
            r = [];
          let s = e[0] * i,
            u = s,
            o = 0;
          r[0] = `${u} ${o}`;
          let l,
            h,
            c,
            f = 1;
          for (let a = 1; a < 8; a++)
            ((l = (a + 6) % 8),
              (s = e[b[a]] * i),
              (h = t * w[a] + y[a] * s),
              (c = n * w[l] + y[l] * s),
              !s || a % 2
                ? c === o
                  ? h !== u && (r[f++] = "h" + (h - u))
                  : (r[f++] = "v" + (c - o))
                : (r[f++] = `a${s} ${s} 0 0 1 ${h - u} ${c - o}`),
              (u = h),
              (o = c));
          return (
            s && (r[f] = `a${s} ${s} 0 0 1 ${s - u} ${-o}`),
            `M${r.join("")}Z`
          );
        })(t, n, e);
      },
      d,
      J,
    ]),
    R(18, [
      function ([t, n, e, i]) {
        return (function (t, n, e, i) {
          i = i * _ - A;
          const r = (2 * Math.PI) / t,
            s = [];
          let u,
            o,
            l,
            h,
            c,
            f,
            a = n * Math.cos(i),
            p = n * Math.sin(i);
          if (((s[0] = `${a} ${p}`), !e)) {
            for (let e = 1; e <= t; e++)
              ((a = n * Math.cos(i)),
                (p = n * Math.sin(i)),
                (s[e] = `${a} ${p}`),
                (i += r));
            return `M${s.join("L")}Z`;
          }
          ((u = (e *= n / 4) * Math.cos(i - A)),
            (o = e * Math.sin(i - A)),
            (i += r));
          for (let d = 1; d <= t; d++)
            ((l = n * Math.cos(i)),
              (h = n * Math.sin(i)),
              (c = e * Math.cos(i - A)),
              (f = e * Math.sin(i - A)),
              (s[d] = `${a - u} ${p - o} ${l + c} ${h + f} ${l} ${h}`),
              (a = l),
              (p = h),
              (u = c),
              (o = f),
              (i += r));
          return `M${s.join("C")}Z`;
        })(t, n, e, i);
      },
      d,
      J,
    ]),
    R(19, [
      function ([t, n, e, i, r, s, u, o]) {
        return (function (t, n, e, i, r, s, u, o) {
          const l = (2 * Math.PI) / t,
            h = [(u + o) * _ - A, (s + o) * _ - A - l / 2],
            c = [e, n],
            f = [];
          let a = c[0] * Math.cos(h[0]),
            p = c[0] * Math.sin(h[0]);
          f[0] = `${a} ${p}`;
          const d = 2 * t;
          if (!i && !r) {
            ((h[0] += l), (h[1] += l));
            for (let t = 1; t < d; t++) {
              const n = t % 2;
              ((a = c[n] * Math.cos(h[n])),
                (p = c[n] * Math.sin(h[n])),
                (f[t] = `${a} ${p}`),
                (h[n] += l));
            }
            return `M${f.join("L")}Z`;
          }
          const g = [r * e * x, i * n * x];
          let M, $, m, v, S, y;
          ((M = g[0] * Math.cos(h[0] - A)),
            ($ = g[0] * Math.sin(h[0] - A)),
            (h[0] += l),
            (h[1] += l));
          for (let t = 1; t <= d; t++) {
            const n = t % 2;
            ((m = c[n] * Math.cos(h[n])),
              (v = c[n] * Math.sin(h[n])),
              (S = g[n] * Math.cos(h[n] - A)),
              (y = g[n] * Math.sin(h[n] - A)),
              (f[t] = `${a - M} ${p - $} ${m + S} ${v + y} ${m} ${v}`),
              (a = m),
              (p = v),
              (M = S),
              ($ = y),
              (h[n] += l));
          }
          return `M${f.join("C")}Z`;
        })(t, n, e, i, r, s, u, o);
      },
      d,
      J,
    ]),
    R(20, [
      function (t) {
        let n;
        for (let e = 0; e < t.length; e++) {
          if (!m[e]) continue;
          const i = m[e](t[e]);
          i && (n ? S(n, i, n) : (n = i));
        }
        return n || v;
      },
      V,
      U,
    ]));
  class nt {
    constructor(t, n, e, i) {
      ((this.t = t),
        (this.p = n),
        (this.c = e),
        (this.v = i),
        (this.iv = null == i));
    }
    update(t) {
      const n = this.t;
      let e = !1;
      if (this.v) {
        const i = a(t, this.v);
        if (this.iv === i) {
          if (!i) return !1;
        } else {
          if (((this.iv = i), (n.style.display = i ? "inline" : "none"), !i))
            return !0;
          e = !0;
        }
      }
      if (this.c) for (const n of this.c) n.update(t) && (e = !0);
      if (this.p)
        for (const [i, r] of this.p)
          r.update(t) && ((e = !0), n.setAttribute(i, r.toString()));
      return e;
    }
  }
  function et(t, n) {
    const e = n.r.getElementById(
      "string" == typeof t[0] ? t[0] : `${n.p}:${t[0]}`,
    );
    if (!e) return null;
    let i;
    if (t[1])
      for (const r of t[1]) {
        const t = Y(n, r[1], r[2], r[3], r[4]);
        if (!t) continue;
        const s = "string" == typeof r[0] ? r[0] : n.t[r[0]];
        t.isAnimated
          ? (i ??= new Map()).set(s, t)
          : e.setAttribute(s, t.toString());
      }
    const r = it(n, t[2] || null),
      s = p(t[3] || null, n.d, n.s);
    return i || r || s ? new nt(e, i, r, s) : null;
  }
  function it(t, n) {
    if (!n || !n.length) return null;
    let e;
    for (const i of n) {
      const n = et(i, t);
      n && (e ??= []).push(n);
    }
    return e;
  }
  const rt = [
    null,
    (t) => t.play(),
    (t) => t.pause(),
    (t) => t.stop(),
    (t) => t.reverse(),
    (t) => t.restart(),
    (t) => t.toggle(),
  ];
  class st {
    constructor(t, n, e, i, r, s) {
      ((this.alternate = !1),
        (this.time = 0),
        (this._fo = null),
        (this._to = 0),
        (this._frame = (t) => {
          (null === this._fo && (this._fo = t),
            this.seek((t - this._fo) * this.speed + this._to) &&
              (this._fi = requestAnimationFrame(this._frame)));
        }),
        (this.root = t),
        (this.targets = n),
        (this.duration = e),
        (this.repeat = i || 1 / 0),
        (this.alternate = !!r),
        (s ||= 1),
        (this.speed = Math.abs(s)),
        (this.direction = Math.sign(s)));
    }
    seek(t) {
      t = Math.round(t);
      const n = this.duration;
      if (t >= n * this.repeat) {
        let t = this.direction < 0 ? 0 : n;
        if (
          ((this.alternate && (this.repeat - 1) % 2 != 1) || (t = n - t),
          this.time !== t)
        )
          for (const n of this.targets) n.update(t);
        return !1;
      }
      if (this.time === t) return !0;
      this.time = t;
      const e = Math.trunc(t / n);
      ((t %= n),
        this.alternate && e % 2 == 1 && (t = n - t),
        this.direction < 0 && (t = n - t));
      for (const n of this.targets) n.update(t);
      return !0;
    }
    play() {
      this._fi ||
        ((this._fo = null),
        (this._to = this.time),
        (this._fi = requestAnimationFrame(this._frame)));
    }
    pause() {
      this._fi && (cancelAnimationFrame(this._fi), (this._fi = 0));
    }
    toggle() {
      this._fi ? this.pause() : this.play();
    }
    stop() {
      (this.pause(), this.seek(0));
    }
    reverse() {
      ((this.direction = -this.direction),
        (this._fo = null),
        (this._to = this.time));
    }
    restart() {
      (this.stop(), this.play());
    }
  }
  function ut(t, n, e) {
    e && rt[e] && t.root.addEventListener(n, () => rt[e](t));
  }
  if (void 0 !== typeof window) {
    const t = "ExpressiveAnimatorPlayer";
    window[t] ||
      ((function (t) {
        e = t;
      })([
        h,
        function (t, n, e, i) {
          return h(1 - e, 1 - i, 1 - t, 1 - n);
        },
        function (t) {
          return (n) => Math.ceil(n * t) / t;
        },
        function (t) {
          return (n) => 1 - Math.ceil((1 - n) * t) / t;
        },
        s,
        r(s),
        o,
        r(o),
        u,
        r(u),
        function (t = 2) {
          return (
            (t *= 2 * Math.PI),
            (n) => ((n = t * (n - 1)), Math.sin(n) / n)
          );
        },
        function (t = 2) {
          return ((t *= -2 * Math.PI), (n) => ((n *= t), 1 - Math.sin(n) / n));
        },
        l,
        r(l),
      ]),
      (window[t] = function (t, n, e) {
        if (!t || t instanceof SVGSVGElement) {
          const i = (function (t, n = "expressive=") {
            if (!t) return null;
            let e = t.firstChild;
            for (; e; ) {
              const t = e.nodeType;
              if (8 === t) break;
              if (3 !== t) return null;
              e = e.nextSibling;
            }
            if (!e) return null;
            const i = e.textContent;
            return i.substring(0, n.length) !== n
              ? null
              : JSON.parse(i.substring(n.length));
          })(t || document.currentScript.closest("svg"));
          if (!i) return null;
          ((t = i[0]), (n = i[1]), (e = i[2]));
        }
        if (!n) return null;
        const i = document.getElementById(`${t.prefix}:0`);
        if (!(i instanceof SVGSVGElement)) return null;
        const r = (function (t, n, e, i, r, s) {
          return it({ r: n, d: i, s: 1, p: e, t: s, e: it }, t);
        })(n, i, t.prefix, t.duration, 0, e);
        if (!r) return null;
        const s = new st(i, r, t.duration, t.repeat, t.alternate, t.speed);
        return (
          (function (t, n = 0, e) {
            if (
              ((function (t, n) {
                n &&
                  (1 !== n
                    ? 2 === n &&
                      new IntersectionObserver(
                        (n) => {
                          for (const e of n)
                            if (e.target === t.root)
                              return void (e.isIntersecting
                                ? t.play()
                                : t.pause());
                        },
                        { root: null, threshold: 0 },
                      ).observe(t.root)
                    : "complete" === document.readyState
                      ? t.play()
                      : document.addEventListener("readystatechange", () => {
                          "complete" === document.readyState && t.play();
                        }));
              })(t, n),
              !e)
            )
              return;
            const i = ["click", "mouseenter", "mouseleave"];
            for (let n = 0; n < 3; n++) ut(t, i[n], e[n]);
          })(s, t.load || 0, t.actions),
          s
        );
      }));
  }
})();
